"""
	fixmarkerspacing takes as input two vectors x and y which should be graphed
	and outputs a subset of observations newx newy such that markers plotted
	using newx newy will be evenly spaced in the original series.

	Example:
	```
		using Plots, StatsFuns
		pyplot()
		x = -10:0.05:10
		y = logistic.(x)
		newx, newy = evenmarkerspacing(x, y, 0.2, 20, 1)
		plot([], [], markershape = :square, label = "foo", linecolor = :blue, markercolor = :red)
		plot!(x, y, linecolor = :blue, label = "")
		plot!(newx, newy, line = false, markershape = :square, label = "", markercolor = :red)
	```
"""
function evenmarkerspacing(x, y, maxspace, rangex, rangey)
	newx = [x[1]]
	newy = [y[1]]
	sumnorm = 0
	for i ∈ 2:length(x)
		sumnorm += sqrt(((x[i] - x[i-1])/rangex)^2 + ((y[i] - y[i-1])/rangey)^2)
		if sumnorm > maxspace
			push!(newx,x[i])
			push!(newy,y[i])
			sumnorm -= maxspace
			if sumnorm > maxspace # In case a jump in y was very large
				sumnorm = 0
			end
		end
	end
	return newx, newy
end

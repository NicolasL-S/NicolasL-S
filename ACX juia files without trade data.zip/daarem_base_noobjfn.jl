"""
	daarem_base_noobjfn is an improved Anderson acceleration (without objective
	function) by Henderson and Varadhan (2019), adapted from the R package 
	"daarem" v. 0.5 by Lepage-Saucier (2021).

	Reference

	Henderson, N. and Varadhan, R. (2019). Damped Anderson acceleration with 
	restarts and monotonicity control for accelerating EM and EM-like algorithms. 
	Journal of Computational and Graphical Statistics 28: 834–846.
"""

include("DampingFind.jl")
function daarem_base_noobjfn(par, fixptfn; maxiter=1_000_000, tol=1.e-08, resid_tol=0.95, 
	a1 = 1.2, κ = 25, order=5, nnorm = Inf, time_limit = 1000)

	start_time = time()
	nparams = length(par)
	nlag = Int64(min(order, ceil(nparams/2)))

	Fdiff = zeros(Float64,nparams,nlag)
	Xdiff = zeros(Float64,nparams,nlag)

	ρ = resid_tol

	xold = par[:]
	xnew, x_propose = (similar(xold),similar(xold))
	fnew, f_propose = (similar(xold),similar(xold))
	fixptfn(xnew, xold)
	fold = xnew - xold
	fixptfn(fnew, xnew)
	fnew .-= xnew
	ss_resids = norm(fnew, nnorm)

	fp_evals = 2
	k = 1
	n_aa = 0
	count = 0
	shrink_count = 0
	shrink_target = 1/(1 + a1^κ)
	λ_ridge = 100000
	r_penalty = 0
	conv = true
	while fp_evals < maxiter && time() - start_time < time_limit
		count += 1
		
		Fdiff[:,count] .= fnew .- fold
		Xdiff[:,count] .= xnew .- xold
		
		np = count
		if np==1
			Ftmp = repeat(Fdiff[:,1], 1,np)
			Xtmp = repeat(Xdiff[:,1], 1,np)
		else
			Ftmp = Fdiff[:,1:np]
			Xtmp = Xdiff[:,1:np]  
		end
		tmp = svd(Ftmp)
		dvec = tmp.S[:]
		dvec_sq = dvec .* dvec
		uy = tmp.U' * fnew
		uy_sq = uy .* uy

		### Still need to compute Ftf
		Ftf = sqrt(sum(uy_sq .* dvec_sq))
		DampingFind(uy_sq, dvec, a1, κ, shrink_count, Ftf; λ_start=λ_ridge, r_start = r_penalty)
		λ_ridge, r_penalty = DampingFind(uy_sq, dvec, a1, κ, shrink_count, Ftf; λ_start=λ_ridge, r_start = r_penalty)
		dd = (dvec .* uy) ./ (dvec_sq .+ λ_ridge)
		γ_vec = tmp.Vt' * dd

		x_propose .= xnew .- (Xtmp * γ_vec)[:,1] .+ fnew .- (Ftmp * γ_vec)[:,1]
			
		fixptfn(f_propose, x_propose)
		f_propose .-= x_propose
		fp_evals += 1
		ss_propose = norm(f_propose, nnorm)
		fold .= fnew[:]
		xold .= xnew[:]
		if ss_propose <= ss_resids * (1.00 + ρ^k)
			## Increase delta
			xnew .= x_propose[:]
			fnew .= f_propose[:]
				
			shrink_count += 1
			ss_resids = ss_propose
			n_aa += 1
		else
			## Keep delta the same
			xnew .= fold .+ xold
			
			fixptfn(fnew, xnew)
			fnew .-= xnew
			ss_resids = norm(fnew, nnorm)
			fp_evals += 1
		end

		if ss_resids < tol && count == nlag; break end
		
		if count == nlag
			count = 0
			## restart count
		end
		shrink_target =  1/(1 + a1^(κ - shrink_count))
		k += 1
	end
			#=
			return (par = xnew, fpevals = fp_evals, value_objfn = nothing, 
				objfevals = nothing, convergence = fp_evals < maxiter, 
				objfn_track = nothing, n_aa = n_aa)
				=#
	return xnew, fp_evals, 
			fp_evals < maxiter && time() - start_time < time_limit
end
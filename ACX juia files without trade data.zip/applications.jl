"""
    This script executes examples from Lepage-Saucier (2021),
    produces Figures 3 to 10 and Tables 2 to 9 and saves all the outputs in .csv 
    format.

    The three lines following this doc may be changed
    - The appli_num ∈ 1:7 selects which application to run
    - The spec ∈ {1,2} selects the specification (appli 5 and 6 have a spec 2)
    - already_computed ∈ {true,false} 

    Each application generates its own functions and changes parameters when
    needed. More detail about each algorithm is available in their respective
    .jl file. 
    
    Note, for logistic, Rosenbrock and CUTEst applications, the	stopping 
    criterion is integrated into the gradient function to make sure all
    algorithms stop with the exact same condition.
"""

# Note: to remove an application, just remove it from appli_list
appli_list = [
    "Rosenbrock" , "logistic"   , "CUTEst"     , "mixtures"   , "tensor"     ,
    "eigenvalues", "altproj"    , "censPHEM"   ]

modif_param_dict = Dict() # Will be populated by include(appli_name*"_fcts.jl")
gen_problem_dict = Dict() # Will be populated by include(appli_name*"_fcts.jl")
nspecs_dict = Dict()

for appli_name ∈ appli_list
    nspecs_dict[appli_name] = 1 # will be modified by some applis
    include(appli_name * "_fcts.jl")
end

function include_draw(stats, par)
    answers = stats[Bool.(stats[:, 4]), 5]
    if length(answers) == 0; return false end
    best = minimum(stats[:, 5])
    discrepant = maximum(answers .- best) > par.discrep_answers
    too_long = minimum(stats[:,3]) > par.time_limit / 8 && length(stats[:,4]) > length(answers) # To make sure the plots are accurate
    too_short = maximum(stats[:,1]) < par.min_maps
    if discrepant; println("Discrepancy: ", maximum(answers .- best), " Not accepted.") end
    if too_long; println("Smallest time: ", minimum(stats[:, 3]), " sec (above ", par.time_limit / 10, " sec). Not accepted.") end
    return !discrepant && !too_long && !too_short
end

filtermean(x, cond) = mean(filter(cond, x))
filtermean(x, cond, dims) = mapslices(x -> filtermean(x, cond), x, dims = dims)

function display_stats_default(stats, good_draws, par; handle = nothing, draw = nothing)
    stats_names = ["Maps", "Obj. ev.", ["sec.", "ms"][1 + par.ms], "Conv", "Minimum"]
    algonames = [algo_names[i][1] for i ∈ par.algos]
    stat1 = round.(filtermean(stats[good_draws, :, 1], !isinf, 1)[1, :]; digits = 1)
    stat2 = round.(filtermean(stats[good_draws, :, 2], !isinf, 1)[1, :]; digits = 1)
    stat3 = round.(filtermean(stats[good_draws, :, 3] .* 1000^par.ms, !isinf, 1)[1, :]; digits = 2)
    stat4 = round.(mean(stats[good_draws, :, 4], dims = 1)[1, :]; digits = 3)
    stat5 = round.(filtermean(stats[good_draws, :, 5] .+ 
        NaN * (stats[good_draws, :, 4] .== false), !isnan, 1)[1, :]; digits = 15) # Removing those that haven't converge
    table_display([stat1 stat2 stat3 stat4 stat5];
                        rownames = algonames, colnames = stats_names, n_chars0 = 15,
                        cornername = "Algorithm", n_chars = [8, 8, 8, 5, 25], handle)
end

function writeln(text; handle = nothing)
    isnothing(handle) ? println(text) : write(handle, text * "\n")
end

function display_results_default(stats, good_draws, name, par)
    io = open(path_output * "output_" * name * ".txt", "w")
    line = "―"^73
    for handle ∈ (nothing, io)
        writeln(line * "\n" * par.title * "\n" * line; handle)
        display_stats_default(stats, good_draws, par; handle)
        writeln(line * "\n" * "Fraction of included draws: " * 
            string(mean(good_draws)) * "\nNumber of parameters: " * 
            string(par.nparams) * "\n" * line ; handle)
    end
    close(io)
end

Base.@kwdef mutable struct parameters
    # acx options 
    stabilize = false
    lower = nothing
    upper = nothing
    buffer = 0.1
    σ_min = 0.0
    use_obj = false
    check_obj = false

    #qnamm options
    non_monotone = false # Also valid for daarem_base_objfn

    # General options
    time_limit = 100
    ndraws = 2000
    nruns = 5 # Runs per draw
    tol = 1e-7
    add_time = 0 # By default, we neglect pre-computation times (exception: eigenvalues, spec 2)

    freq_display = 10
    ms = false # Should the time be displayed in miliseconds

    discrep_answers = 1e-5 # To reject draws where optimums were too different
    min_maps = 0      # To reject draws that took too few mappings (CUTEst)
    mult_mappings = 1 # Some algorithms (eg eigenvalues) involve 2 iterations per mapping

    show_plot = true

    display_stats   = display_stats_default   # Will be modified in CUTEst
    display_results = display_results_default # Will be modified in CUTEst

    # Problem specific
    title   = "" # for display_results
    nparams = 0  # for display_results
    to_compute = true
    
    algos = [1, 2, 3]
end

function solve(p, par, i_algo)
    algo, algo_option = algorithms[par.algos[i_algo]]
    c = false
    boosts = fails = obj_fin = 0
    times = Inf * ones(par.nruns + 1)
    time_limit = par.time_limit
    maps_limit = 1_000_000_000_000
    for r ∈ 0:par.nruns
        if algo == speedmapping
            haskey(p, :f ) ? f  = p.f  : f = nothing
            haskey(p, :m!) ? m! = p.m! : m! = nothing
            haskey(p, :g!) ? g! = p.g! : g! = nothing
            haskey(p, :g!) && par.upper == Inf ? tol = 0.0 : tol = par.tol # The tol is in g!

            t = @elapsed x, m, fs, c = speedmapping(p.x_in; g!, m!, f,
                lower = par.lower, upper = par.upper, stabilize = par.stabilize,
                buffer = par.buffer, σ_min = par.σ_min, Lp = Inf, orders = algo_option, 
                tol, maps_limit, time_limit)
            
        elseif algo == qnamm
            t = @elapsed x, m, fs, _, _, c = qnamm(p.x_in, p.m!, algo_option, p.f; 
                maps_limit, tol = [par.tol, Inf, Inf], verb = 0, 
                time_limit, par.non_monotone)
            
        elseif algo == optimize
            t = @elapsed res = optimize(p.f, p.g!, p.x_in, algo_option, 
                Optim.Options(g_tol = 0, f_tol = 0, iterations = maps_limit, 
                    x_tol = 0, g_calls_limit = maps_limit, allow_f_increases = true, 
                    time_limit = time_limit))
            x, m, fs, c = (Optim.minimizer(res), Optim.g_calls(res),
                                Optim.f_calls(res)  , Optim.converged(res))

        elseif algo == "opt_constr"
            lower = -Inf*ones(length(par.upper))
            t = @elapsed res = optimize(p.f, p.g!, lower, 
                par.upper, p.x_in, Fminbox(algo_option),
                Optim.Options(g_tol = par.tol, f_tol = 0, iterations = maps_limit,
                    x_tol = 0, g_calls_limit = maps_limit, allow_f_increases = true, 
                    time_limit = time_limit))
            x, m, fs, c = (Optim.minimizer(res), Optim.g_calls(res),
                                Optim.f_calls(res)  , Optim.converged(res))

        elseif algo == no_accel
            t = @elapsed x, m, c = no_accel(p.x_in, p.m!; tol = par.tol, verb = 0, maps_limit, time_limit)
            fs = 0

        elseif algo == eigen
            t = @elapsed res = eigsolve(p.A, 1, :LM)
            x, m, fs, c = (res[2][1], res[3].numops, 0, true)
            
        elseif algo == "Alt proj"
            t = @elapsed _, _,m = alt_proj(p.df)
            m, fs, c = (m, 0, true)

        elseif algo == "Alt proj ACX"
            t = @elapsed _, _,m = alt_proj_acx(p.df, algo_option)
            m, fs, c = (m, 0, true)

        elseif algo == "lsmr"
            t = @elapsed run_lsmr(p.df)
            m, fs, c = (0, 0, true)

        elseif algo == "daarem"
            if isnothing(p.f)
                t = @elapsed x, m, c = daarem_base_noobjfn(p.x_in, p.m!;
                time_limit, tol = par.tol, order = algo_option, maxiter = maps_limit)
                fs = 0
            else
                f(x) = -p.f(x)
                t = @elapsed x, m, fs, c = daarem_base_objfn(p.x_in, p.m!, f;
                    time_limit, tol = par.tol, order = algo_option, 
                    check_par_resid = true, maxiter = maps_limit, par.non_monotone)
            end
        end
        
        if p.f !== nothing; obj_fin = p.f(x) end

        if isnan(obj_fin) || isinf(obj_fin); c = false end
        info = "$i_algo: " * "NOT "^(!c) * "converged "
        if !c; return (Inf, Inf, Inf, false, obj_fin), info end
        times[r + 1] = t + par.add_time # for extra calculations
        if r == par.nruns || (r == 5 && median(sort(times)[1:3]) > 0.1) || (r == 1 && minimum(times) > 10)
            return (m * par.mult_mappings, fs, median(sort(times)[1:r]), c, obj_fin), info
        end
    end
end

function compute_appli!(appli, spec, par, stats, good_draws)
    Random.seed!(123)
    R"set.seed(123)"
    t_start = time()
    for draw ∈ 1:par.ndraws
        p = gen_problem_dict[appli](par, spec, draw)
        print("\n", par.title, " draw: $draw ")
        infos = ["" for i ∈ 1:length(par.algos)]
        println()
        @showprogress for i_algo ∈ 1:length(par.algos)
            res = [Inf, Inf, Inf, false, NaN]
                res, infos[i_algo] = solve(p, par, i_algo)
            if draw > 0; stats[draw, i_algo, :] .= res end
        end
        println(prod(infos))
        good_draws[draw] = include_draw(stats[draw, :, :], par)
        if mod(draw, par.freq_display) == 0 && maximum(good_draws)
            par.display_stats(stats, good_draws, par; draw)
            if par.show_plot; plot_draws(stats[good_draws, :, 3], par.algos) end
            time_left = (time() - t_start) / draw * (par.ndraws - draw) |> round |> 
                Int |> Dates.Second |> Dates.CompoundPeriod |> Dates.canonicalize
            println("Time left: $time_left")
        end
        if haskey(p, :nlp); finalize(p.nlp) end
    end
end

pathname(name, suf) = path_output * "res_" * name * "_" * suf * ".csv"
function save_results(stats, good_draws, name)
    for s ∈ 1:5
        writedlm(pathname(name, "stat$s"), stats[:,:,s], ',')
    end
    writedlm(pathname(name, "goodDraws"),  good_draws, ',')
end

function load_results(name, par)
    stats_load = zeros(par.ndraws, length(par.algos), 5)
    for s ∈ 1:5
        m = CSV.read(pathname(name, "stat$s"), DataFrame; header = 0, delim = ',')
        stats_load[:,:,s] .= Matrix(m)
    end
    m = CSV.read(pathname(name, "goodDraws"), DataFrame;  header = 0, delim = ',')
    good_draws_load = Bool.(Matrix(m)[:,1])
    return stats_load, good_draws_load
end

function run_appli(appli, spec; save = false)
    par = modif_param_dict[appli](parameters())
    if par.to_compute
        stats = zeros(par.ndraws, length(par.algos), 5)
        good_draws = falses(par.ndraws)
        compute_appli!(appli, spec, par, stats, good_draws)
        if save
            applispec = appli * "_spec$spec"^(spec > 1)
            par.display_results(stats, good_draws, applispec, par)
            save_results(stats, good_draws, applispec)
            if par.show_plot
                plot_draws(stats[good_draws,:,3], par.algos)
                savefig(path_output * applispec * ".eps")
            end
        end
    end
end

function run_applis(appli_list)
    for appli ∈ appli_list
        for spec ∈ 1:nspecs_dict[appli]
            run_appli(appli, spec; save = true)
        end
    end
end

function load_appli(appli, spec; algos = false)
    par = modif_param_dict[appli](parameters())
    p = gen_problem_dict[appli](par, spec, 1)
    applispec = appli * "_spec$spec"^(spec > 1)
    stats, good_draws = load_results(applispec, par)
    if algos == false; 
        algos = 1:size(stats,2) 
    else
        par.algos = par.algos[algos]
    end
    par.display_results(stats[:,algos,:], good_draws, applispec, par)
    if par.show_plot
        plot_draws(stats[good_draws, algos, 3], par.algos) 
        savefig(path_output * applispec * ".eps")
    end
end

run_applis(appli_list)
#run_appli("altproj", 2; save = true)
#load_appli("tensor", 1; algos = [1,2,3,5,9,10])
"""
	daarem_base_objfn is an improved Anderson acceleration (with objective
	function) by Henderson and Varadhan (2019), adapted from the R package 
	"daarem" v. 0.5 by Lepage-Saucier (2021).

	Reference

	Henderson, N. and Varadhan, R. (2019). Damped Anderson acceleration with 
	restarts and monotonicity control for accelerating EM and EM-like algorithms. 
	Journal of Computational and Graphical Statistics 28: 834–846.
"""

using LinearAlgebra
include("DampingFind.jl")
function daarem_base_objfn(par, fixptfn, objfn; maxiter = 1_000, tol = 1e-8, 
	mon_tol = 0.01, cycl_mon_tol=0.0, a1 = 1.2, κ=25, check_par_resid = false, 
	order = 5, Lp = Inf, time_limit = 1000, non_monotone = false)

	#maxiter = control$maxiter
	#tol = control$tol
	#mon_tol = control$mon_tol  ## monotonicity tolerance
	#cycl_mon_tol = control$cycl_mon_tol
	#a1 = control$alpha
	#κ = control$κ

	start_time = time()
	nparams = length(par)
	nlag = Int64(min(order, ceil(nparams/2)))

	Fdiff = zeros(Float64,nparams,nlag)
	Xdiff = zeros(Float64,nparams,nlag)

	#obj_funvals = Vector{Float64}(undef,maxiter + 2)
  
	xold = copy(par)
	xnew, x_propose, fnew = (similar(xold),similar(xold),similar(xold))

	if non_monotone
		best_x = copy(par)
		obj_best = -Inf
	end

	fixptfn(xnew, xold)
	fp_evals = 1 # NL-S Do this to have the proper function count (was off by 1)
	#obj_funvals[1] = objfn(xold)
	#obj_funvals[2] = objfn(xnew)
	old_funval = new_funval = objfn(xnew)
	#likchg = obj_funvals[2] - obj_funvals[1] # NL-S This doesn't do anything
	obj_evals = 2
	
	fold = xnew - xold
	k = 1
	count = 0
	shrink_count = 0
	# shrink_target = 1/(1 + a1^κ) # NL-S This doesn't do anything
	λ_ridge = 100000
	r_penalty = 0
	# conv = true # NL-S removed, this doesn't do anything anymore
	#ell_star = obj_funvals[2]
	ell_star = old_funval
	while k < maxiter &&  time() - start_time < time_limit
		count += 1

		fixptfn(fnew, xnew)
		fp_evals += 1
		fnew .-= xnew

		ss_resids = norm(fnew, Lp)
		if ss_resids < tol && check_par_resid; break end
		#new_objective_val >= obj_funvals[k+1] - mon_tol

		Fdiff[:,count] .= fnew .- fold
		Xdiff[:,count] .= xnew .- xold

		np = count
		if np==1
			Ftmp = repeat(Fdiff[:,1], 1,np)
			Xtmp = repeat(Xdiff[:,1], 1,np)
		else
			Ftmp = Fdiff[:,1:np]
			Xtmp = Xdiff[:,1:np]  
		end
		tmp = svd(Ftmp)
		dvec = tmp.S[:]
		dvec_sq = dvec .* dvec
		uy = tmp.U' * fnew
		uy_sq = uy .* uy
    
		### Still need to compute Ftf
		Ftf = sqrt(sum(uy_sq .* dvec_sq))
		λ_ridge, r_penalty = DampingFind(uy_sq, dvec, a1, κ, shrink_count, Ftf; λ_start=λ_ridge, r_start = r_penalty)
		
		dd = (dvec .* uy) ./ (dvec_sq .+ λ_ridge)
		γ_vec = tmp.Vt' * dd
		x_propose .= xnew .- (Xtmp * γ_vec)[:,1] .+ fnew .- (Ftmp * γ_vec)[:,1]

		new_objective_val = NaN
		#try
			new_objective_val = objfn(x_propose)
		#catch
		#	new_objective_val = -Inf
		#end
		if new_objective_val == NaN || isinf(new_objective_val)
			new_objective_val =  -Inf
		end
		obj_evals += + 1

		fold .= fnew[:]
		xold .= xnew[:]
		#if !isnan(new_objective_val) && !isinf(new_objective_val) && !isnan(obj_funvals[k+1])
		if !isnan(new_objective_val) && !isinf(new_objective_val) && !isnan(old_funval)
			#if new_objective_val >= obj_funvals[k+1] - mon_tol  ## just change this line in daarem_base_noobjfn
			if new_objective_val >= old_funval - mon_tol  ## just change this line in daarem_base_noobjfn
				## Increase delta
				#obj_funvals[k+2] = new_objective_val
				new_funval = new_objective_val
				xnew .= x_propose[:]
				shrink_count += 1
			else
				## Keep delta the same
				xnew .= fold .+ xold
				#obj_funvals[k+2] = objfn(xnew)
				new_funval = objfn(xnew)
				obj_evals +=  1
			end
		else
			## Keep delta the same
			xnew .= fold .+ xold
			#obj_funvals[k+2] = objfn(xnew)
			new_funval = objfn(xnew)
			obj_evals += 1
			count = 0
		end

#		if non_monotone && !isnan(obj_funvals[k+2]) && !isinf(obj_funvals[k+2])  && obj_funvals[k+2] > obj_best
		if non_monotone && !isnan(new_funval) && !isinf(new_funval)  && new_funval > obj_best
			best_x .= xnew
			#obj_best = obj_funvals[k+2]
			obj_best = new_funval
		end

		if count==nlag
			count = 0
			## restart count
			## make comparison here l_star vs. obj_funvals[k+2]
			#if obj_funvals[k+2] < ell_star - cycl_mon_tol
			if new_funval < ell_star - cycl_mon_tol
				## Decrease delta
				shrink_count = max(shrink_count - nlag, -2*κ)
			end
			#ell_star = obj_funvals[k+2]
			ell_star = new_funval
		end
		#if abs(obj_funvals[k+2] - obj_funvals[k+1]) < tol && !check_par_resid
		if abs(new_funval - old_funval) < tol && !check_par_resid
			break
		end
		# shrink_target =  1/(1 + a1^(κ - shrink_count)) # NL-S This doesn't do anything
		k += 1
		old_funval = new_funval
	end
	
	#obj_funvals = obj_funvals[!isnan.(obj_funvals)] # NL-S Removed for streamlining
	#value_obj = objfn(xnew, ...) # NL-S Removed for streamlining
	if non_monotone; xnew .= best_x end

	return xnew, fp_evals, obj_evals,
			fp_evals < maxiter && time() - start_time < time_limit
end
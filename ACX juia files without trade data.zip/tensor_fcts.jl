gen_problem_tensor(par, spec, draw) = (start = ones(450),) # Fake start for output purposes

function modif_par_tensor!(par)
    println("ALS for canonical tensor decomposition computated in MATLAB")
    par.title      = "ALS for canonical tensor decomposition" # To be fed to display_results
    par.algos      = [1, 2, 3, 4, 5, 6, 16, 17, 18, 21]
    par.to_compute = false
    par.nparams    = 450
    return par
end

if @isdefined modif_param_dict
    modif_param_dict["tensor"] = modif_par_tensor!
    gen_problem_dict["tensor"] = gen_problem_tensor
end
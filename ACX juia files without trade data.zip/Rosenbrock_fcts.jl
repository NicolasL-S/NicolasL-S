"""
    Defines functions for the Rosenbrock function
"""

const N = 500

f_Rosenbrock(x) = sum(100 * (x[i]^2 - x[i+N])^2 + (x[i] - 1)^2 for i ∈ 1:N)

function g_Rosenbrock!(∇, x) # Rosenbrock gradient
    ∇[1:N] .=  400(x[1:N].^2 .- x[N + 1:2N]) .* x[1:N] .+ 2(x[1:N] .- 1)
    ∇[N + 1:2N] .= -200(x[1:N].^2 .- x[N + 1:2N])
    return nothing
end

function gen_problem_Rosenbrock!(par, spec, draw)
    x_in = spec == 1 ? 10(rand(2N) .- .5) : x_in = -5rand(2N)
    if spec == 2; par.algos = [1, 2, 3, 22, 23] end

    function ∇_Rosenbrock_stop!(∇, x, spec)
        g_Rosenbrock!(∇, x)
        if spec == 1 && norm(∇, Inf) ≤ par.tol # To make sure that all algorithms stop with the exact same criterion
            ∇ .= zeros(2N)
        end
        return nothing
    end

    if spec == 2; par.upper = rand(2N) end

    return (
        f    = x -> f_Rosenbrock(x), 
        g!   = (∇, x) -> ∇_Rosenbrock_stop!(∇, x, spec),
        x_in = x_in)
end

function modif_par_Rosenbrock!(par)
    par.title = "Rosenbrock" # To be fed to display_results
    par.ms    = true
    par.algos = [1, 2, 3, 7, 8]
    par.buffer = 0.001
    par.nparams = 1000
    return par
end

if @isdefined modif_param_dict
    modif_param_dict["Rosenbrock"] = modif_par_Rosenbrock!
    gen_problem_dict["Rosenbrock"] = gen_problem_Rosenbrock!
    nspecs_dict["Rosenbrock"]      = 2
end
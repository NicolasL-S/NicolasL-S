using LaTeXStrings: eachindex
"""
    Example_Rosenbrock plots the estimation of ACX 2 and ACX 3,2 starting
    from the point (0,0). It generates Figure 2.
"""

using BenchmarkTools, LaTeXStrings, Distributions, Optim, Random, LineSearches, Plots
include("main.jl")
include("Constants.jl")
include("table_display.jl")

Random.seed!(1234)

f_Rosenbrock2(x) = 100 * (x[1]^2 - x[2])^2 + (x[1] - 1)^2

function g_Rosenbrock2!(∇, x) # Rosenbrock gradient
    ∇[1] = 400(x[1]^2 - x[2]) * x[1] + 2(x[1] - 1)
    ∇[2] = -200(x[1]^2 - x[2])
    return nothing
end

function main_check_progress()
    res = speedmapping([0.0, 0.0]; orders = [3, 2], f = f_Rosenbrock2, g! = g_Rosenbrock2!,
        store_info = true)

    psAll = res.info.p
    xs = reshape(vcat(res.info.x'...), length(res.info.x), length(res.info.x[1]))[psAll.!=1, :]
    ps = psAll[psAll.!=1]
    x_range = -0.2:0.001:1.2
    y_range = -0.2:0.001:1.2
    X = repeat(reshape(x_range, 1, :), length(y_range), 1)
    Y = repeat(y_range, 1, length(x_range))
    obj2(x1, x2) = (f_Rosenbrock2([x1, x2]))^0.2
    Z = map(obj2, X, Y)
    pl = contour(x_range, y_range, color = :grays, Z, colorbar = false)

    color1, shape1, style1 = algo_lines[1]
    color2, shape2, style2 = algo_lines[2]
    color3, shape3, style3 = algo_lines[3]

    pl = plot!(xs[:, 1], xs[:, 2],
        linecolor = color2, label = algo_names[2][2], markerstrokecolor = nothing,
        xlabel = L"x_1", ylabel = L"x_2", linewidth = linewidth)
    pl = scatter!(xs[ps.==2, 1], xs[ps.==2, 2], markersize = markersize,
        markershape = shape1, markerstrokecolor = color1, label = "Square. extr.",
        markercolor = :white, markerstrokewidth = linewidth)
    pl = scatter!(xs[ps.==3, 1], xs[ps.==3, 2], markersize = markersize,
        markershape = shape3, markerstrokecolor = color3, label = "Cubic extr.",
        markercolor = :white, legend = (0.01, 0.71), markerstrokewidth = linewidth,
        bg = :white, size = sizePlot, legendfontsize = fsl,
        xtickfontsize = small_font, ytickfontsize = small_font,
        yguidefontsize = fs,
        xguidefontsize = fs, foreground_color_grid = lGrey,
        foreground_color_legend = lGrey)
    display(pl)
    savefig(path_output * "Rosenbrock_example.eps")
    savefig(path_output * "Rosenbrock_example.png")
end

main_check_progress()
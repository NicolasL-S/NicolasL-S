"""
	qnamm adapts the quasi-Newton method of Zhou et al. (2011) from its R
	package.

	Reference

	Zhou, H., Alexander, D. and Lange, K. (2011). A quasi-Newton acceleration for 
		high-dimensional optimization algorithms. Statistics and computing 21: 
		261–273.

	qnamm: https://rdrr.io/cran/splitFeas/man/qnamm.html
"""

function qnamm(x_in :: AbstractVector, fx_mm!, qn, fx_obj; 
	maps_limit = 10_000, tol = [1e-8,Inf,Inf], 
	verb = 1, compute_e = nothing, no_f_check = false, time_limit = 1000, non_monotone = false)

	start_time = time()

	n = length(x_in)
	x, x_qn, x_qn_last, x_old = (copy(x_in), similar(x_in), similar(x_in), similar(x_in)) 
	if non_monotone
		best_x = copy(x_in)
		obj_best = Inf
	end
	U, V = (Array{Float64}(undef,n, qn), Array{Float64}(undef,n, qn))
	objval = objval_QN = Inf
	#objective = Vector{Float64}(undef,Int64(maps_limit)) # Try Vector{Float128}(max_iter) # Ok c'est juste pour garder les obj..
	e = Inf * Float64.(ones(length(tol))) # The errors

	for i in 1:qn
		x_old .= x[:]
		fx_mm!(x,x)
		U[:, i] .= x .- x_old
	end

	V[:, 1:qn - 1] .= U[:, 2:qn]
	x_old .= x[:]
	fx_mm!(x,x)
	n_maps = qn + 1
	n_obj = 0

	V[:, qn] .= x .- x_old
	old_secant = 1
	C = U'*(U-V)
	nacc = 0
	nrej = 0

	n_cycles = 0
	while n_maps <= maps_limit && time() - start_time < time_limit
		n_cycles += 1
		objval_old = objval
		x_old .= x[:]
		fx_mm!(x,x)
		n_maps += 1
		U[:,old_secant] .= x .- x_old

		# Checking termination conditions (up to 3)
		if tol[1] < Inf; e[1] = norm(U[:,old_secant],Inf) end
		if tol[2] < Inf; e[2] = norm(U[:,old_secant],Inf) / (norm(x_old) + 1) end
		if tol[3] < Inf; e[3] = compute_e(x, x_old) end

		if sum(e .> tol) == 0
			if verb >= 1; println("Converged. Number of mappings: ", n_maps, " ")  end
			return x, n_maps, n_obj, n_cycles, e, true
		end

		x_old .= x[:]
		fx_mm!(x,x)
		n_maps += 1
		V[:,old_secant] .= x .- x_old

		C[old_secant,:] .= (U[:,old_secant]' * (U .- V))'
		C[:,old_secant] .= U' * (U[:,old_secant] .- V[:,old_secant])
		new_secant = old_secant
		old_secant = mod(old_secant,qn) + 1
		if !no_f_check
			objval_MM = fx_obj(x)
			n_obj += 1
		end
		Uu = U' * U[:,new_secant]
		try
			x_qn .= x_old .+ V * pinv(C) * Uu
		catch
			x_qn .= x # Added by NL-S (2021) in case pinv(C) fails
		end
		if no_f_check
			x[:] .= x_qn[:]
		else
			x_qn_last[:] .= x_qn[:]
			n_maps += 1
			try
				fx_mm!(x_qn,x_qn)
			catch
				x_qn[:] .= x_qn_last[:]
			end
			try
				objval_QN = fx_obj(x_qn)
			catch
				objval_QN = Inf
			end
			n_obj += 1
			if !isnan(objval_QN) && !isinf(objval_QN) && objval_QN <= objval_MM
				x[:] .= x_qn[:]
				objval = objval_QN
				nacc = nacc + 1
			else
				objval = objval_MM
				nrej = nrej + 1
			end
			#objective[n_cycles] = objval
			if non_monotone && !isnan(objval) && !isinf(objval) && objval < obj_best
				best_x .= x
				obj_best = objval
			end
		end
	end
	if non_monotone; x .= x_best end
	if verb >= 1 println("Not converged.") end
	return x, n_maps, n_obj, n_cycles, Inf, false
end
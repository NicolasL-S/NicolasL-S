"""
    Defines functions and parameters for the logistic regression
"""

function f_logistic(b, y, X) :: Float64
    f_out = 0
    for i ∈ 1:length(y)
        xib = X[i,:]'b
        f_out -= y[i] * xib + log(logistic(-xib))
    end
    return f_out
end

function g_logistic!(∇, b, y, X)
    ∇ .= -X' * (y .- logistic.(X * b))
    return ∇
end

function gen_problem_logistic!(par, spec, draw)
    m = 100
    n = 2000
    β = 2rand(m) .- 1
    X = [ones(n) 2rand(n,m-1) .- 1]
    y = logistic.(X * β) .> rand(n)

    function g_logistic_stop!(∇,x)
        g_logistic!(∇, x, y, X)
        if norm(∇) ≤ par.tol    # To make sure that all algorithms 
            ∇ .= zeros(length(x)) # stop with the exact same criterion.
        end
        return ∇
    end

    par.title   = "Logistic: n = $n, m = $m"
    par.nparams = m

    return (
        f    = b -> f_logistic(b, y, X), 
        g!   = g_logistic_stop!, 
        x_in = zeros(m))
end

function modif_par_logistic!(par)
    par.ms    = true
    par.algos = [1, 2, 3, 7, 8]
    return par
end

if @isdefined modif_param_dict
    modif_param_dict["logistic"] = modif_par_logistic!
    gen_problem_dict["logistic"] = gen_problem_logistic!
end
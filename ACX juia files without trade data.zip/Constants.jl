"""
	Sets algorithm names, options, colors and graph specifications.
"""

using ColorTypes, LaTeXStrings, Optim
include("qnamm.jl")
include("no_accel.jl")
include("daarem_base_objfn.jl")
include("daarem_base_noobjfn.jl")

algorithms = 
	[(speedmapping  , [2]                ), #  1
	 (speedmapping  , [3, 2]             ), #  2
	 (speedmapping  , [3, 3, 2]          ), #  3
	 (qnamm         , 3                  ), #  4
	 (qnamm         , 5                  ), #  5
	 (qnamm         , 10                 ), #  6
	 (optimize      , LBFGS(; m = 10)    ), #  7 m = 5
	 (optimize      , ConjugateGradient()), #  8
	 (no_accel      , nothing            ), #  9
	 (eigen         , nothing            ), # 10
	 ("Alt proj"    , nothing            ), # 11
	 ("Alt proj ACX", [2]                ), # 12
	 ("Alt proj ACX", [3, 2]             ), # 13
	 ("Alt proj ACX", [3, 3, 2]          ), # 14
	 ("lsmr"        , nothing            ), # 15
	 ("O-Accel"     , 3                  ), # 16
	 ("O-Accel"     , 5                  ), # 17
	 ("O-Accel"     , 10                 ), # 18
	 ("daarem"      , 2                  ), # 19
	 ("daarem"      , 5                  ), # 20
	 ("daarem"      , 10                 ), # 21
	 ("opt_constr"  , LBFGS(; m = 10)    ), # 22
	 ("opt_constr"  , ConjugateGradient())] # 23

algo_names = 
	[("ACX 2"            , "ACX"*L"^{2}"            ), #  1
	 ("ACX 3,2"          , "ACX"*L"^{3,2}"          ), #  2
	 ("ACX 3,3,2"        , "ACX"*L"^{3,3,2}"        ), #  3
	 ("QNAMM (3)"          , "QNAMM (3)"                ), #  4
	 ("QNAMM (5)"          , "QNAMM (5)"                ), #  5
	 ("QNAMM (10)"         , "QNAMM (10)"               ), #  6
	 ("L-BFGS"           , "L-BFGS"                 ), #  7
	 ("Conj Grad"        , "Conj Grad"              ), #  8
	 ("No accel"         , "No accel"               ), #  9
	 ("Krylov-Schur"     , "Krylov-Schur"           ), # 10
	 ("Alt proj"         , "Alt proj"               ), # 11
	 ("ACX 2"            , "ACX"*L"^{2}"            ), # 12
	 ("ACX 3,2"          , "ACX"*L"^{3,2}"          ), # 13
	 ("ACX 3,3,2"        , "ACX"*L"^{3,3,2}"        ), # 14
	 ("LSMR"             , "LSMR"                   ), # 15
	 ("O-Accel (3)"      , "O-Accel (3)"            ), # 16
	 ("O-Accel (5)"      , "O-Accel (5)"            ), # 17
	 ("O-Accel (10)"     , "O-Accel (10)"           ), # 18
	 ("DAAREM (2)"       , "DAAREM (2)"             ), # 19
	 ("DAAREM (5)"       , "DAAREM (5)"             ), # 20
	 ("DAAREM (10)"      , "DAAREM (10)"            ), # 21
	 ("L-BFGS"           , "L-BFGS"                 ), # 22
	 ("Conj Grad"        , "Conj Grad"              )] # 23

dBlue   = RGB(  7/255,  45/255,  95/255)
mBlue   = RGB( 18/255,  97/255, 160/255)
lBlue   = RGB( 56/255, 149/255, 211/255)
dRed    = RGB(150/255,   0/255,   0/255)
mRed    = RGB(255/255,   0/255,   0/255)
lRed    = RGB(255/255, 100/255, 100/255)
dGreen  = RGB(  0/255, 120/255,  70/255)
mGreen  = RGB( 10/255, 200/255,  80/255)
lGreen  = RGB( 20/255, 240/255, 140/255)
black   = RGB(  0/255,   0/255,   0/255)
mgrey   = RGB(120/255, 120/255, 120/255)
dgrey   = RGB( 50/255,  50/255,  50/255)
dPurple = RGB( 90/255,  30/255, 120/255)
mPurple = RGB(110/255,  40/255, 150/255)
lPurple = RGB(150/255, 100/255, 180/255)
dOrange = RGB(255/255,  38/255,   0/255)
mOrange = RGB(255/255,  77/255,   0/255)
lOrange = RGB(255/255, 116/255,   0/255)

algo_lines =
	[(lBlue   , :square   , :dot    ), #  1
	 (mBlue   , :pentagon , :dashdot), #  2
	 (dBlue   , :octagon  , :dash   ), #  3
	 (dGreen  , :cross    , :dot    ), #  4
	 (mGreen  , :xcross   , :dashdot), #  5
	 (lGreen  , :star4    , :dash   ), #  6
	 (dRed    , :utriangle, :dot    ), #  7
	 (mRed    , :dtriangle, :dash   ), #  8
	 (dgrey   , :diamond  , :solid  ), #  9
	 (mgrey   , :circle   , :dot    ), #  10
	 (dgrey   , :diamond  , :solid  ), #  11
	 (lBlue   , :pentagon , :dot    ), #  12
	 (mBlue   , :hexagon  , :dashdot), #  13
	 (dBlue   , :octagon  , :dash   ), #  14
	 (mgrey   , :circle   , :dot    ), #  15
	 (lPurple , :star6    , :dot    ), #  16
	 (mPurple , :star5    , :dashdot), #  17
	 (dPurple , :star8    , :dash   ), #  18
	 (dOrange , :rtriangle, :dot    ), #  19
	 (mOrange , :utriangle, :dashdot), #  20
	 (lOrange , :ltriangle, :dash   ), #  21
	 (dRed    , :utriangle, :dot    ), #  23
	 (mRed    , :dtriangle, :dash   )] #  24
	 
fs_large = 24
fs = 24
fsl = 18
small_font = 18
markersize = 12
linewidth = 3
lGrey = RGB(0.8, 0.8, 0.8)
dGreen = RGB(0, 0.5, 0)
sizePlot = (750, 750)
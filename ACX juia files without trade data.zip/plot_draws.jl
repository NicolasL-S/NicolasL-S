"""
	PlotSets algorithm names, options, colors and graph specifications.
"""

using LaTeXStrings, Plots
include("evenmarkerspacing.jl")
pyplot()

function plot_draws(data, algos; range_delay= 1:0.1:8)
	excess = broadcast(/,data,minimum(data, dims = 2))
	ndraws, nalgos = size(excess)
	cumul = Array{Float64}(undef, length(range_delay), nalgos)
	i = 1
	for d ∈ range_delay
		cumul[i,:] = sum(excess .<= d,dims = 1)/ndraws
		i += 1
	end

	plt = plot([],[], label = "")
	for i ∈ eachindex(algos)
		algo = algos[i]
		label = algo_names[algo][2]
		linecolor, markershape, linestyle = algo_lines[algo]
		plt = plot!([], [], label = label, linecolor = linecolor, 
			linestyle = linestyle, legend = (0.5,0),
			bg=:white, size = sizePlot, linewidth = linewidth, legendfontsize=fsl,
			xtickfontsize = small_font, ytickfontsize = small_font, yguidefontsize=fs, 
			xguidefontsize=fs, foreground_color_grid = lGrey, ylims = (-0.02, 1.02),
			foreground_color_legend = lGrey, markershape = markershape, markerstrokecolor = linecolor, markercolor = :white, xticks = 0:1:maximum(range_delay))
		plt = plot!(range_delay, cumul[:,i], label = "", linecolor = linecolor, linestyle = linestyle, linewidth = linewidth)
		rmark, cmark = evenmarkerspacing(range_delay, cumul[:,i], 0.2, maximum(range_delay) - minimum(range_delay), 1)
		plt = plot!(rmark, cmark, line = false, label = "", markershape = markershape, markerstrokecolor = linecolor, markerstrokewidth = linewidth, markercolor = :white, markersize = markersize)
	end
	display(plt)
end
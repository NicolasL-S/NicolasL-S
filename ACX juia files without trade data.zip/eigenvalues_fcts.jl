"""
    Defines functions and parameters for the power method and inverse power 
    method for dominant eigenvalues.
"""

using KrylovKit, SparseArrays

function gen_problem_eigenvalues!(par, spec, draw)
    d = 1000
    A = Symmetric(sprand(d, d, 0.1) + 100Diagonal(rand(d)))

    Rayleigh(A, x) = x'A*x/x'x

    function map_power!(x_out, x_in)
        mul!(x_out, A, x_in)
        x_out ./= norm(x_out, Inf)
    end

    par.nparams       = d
    return (
        m!   = map_power!,
        f    = x -> Rayleigh(A, x),
        x_in = ones(d),
        A    = A)
end

function modif_par_eigenvalues!(par)
    par.title         = "Eigenvalue: power method"
    par.ms            = true
    par.algos         = [1, 2, 3, 9, 10]
    return par
end

if @isdefined modif_param_dict
    modif_param_dict["eigenvalues"] = modif_par_eigenvalues!
    gen_problem_dict["eigenvalues"] = gen_problem_eigenvalues!
end

"""
	A self-made table display for the results
"""

function table_display(arr::Array; rownames = [""], colnames = [""], 
	cornername = [""], n_chars = 10, n_chars0 = 10, handle = nothing,
	type_cols = nothing)
	handle === nothing ?  fct = print : fct = text -> write(handle, text)
	dims = collect(size(arr))
	if colnames != [""]
		fct(string(SubString(rpad(string(cornername),n_chars0),1,n_chars0)," "))
		for i_col=1:length(colnames)
			n_chars_i = n_chars[min(size(n_chars,1),i_col)]
			fct(string(SubString(lpad(string(colnames[i_col]),n_chars_i),1,n_chars_i)," "))
		end
		fct("\n")
	end
	for i_row=1:size(arr,1)
		if rownames != [""]
			if size(rownames,1) >= i_row
				fct(string(SubString(rpad(string(rownames[i_row]),n_chars0),1,n_chars0)," "))
			else
				fct(" "^n_chars0)
			end
		end
		for i_col=1:size(arr,2)
			isnothing(type_cols) ? t = eltype(arr) : t = type_cols[i_col]
			n_chars_i = n_chars[min(size(n_chars,1),i_col)]
			fct(string(SubString(lpad(string(t(arr[i_row,i_col])),n_chars_i),1,n_chars_i)," "))
		end
		fct("\n")
	end
end
using RCall, Statistics
RCall.@rlibrary(daaremtest)

function InterCensEM!(pvec_out, pvec_in, A, B)
    B .= A .* pvec_in'
    pvec = mean(B ./ sum(B; dims = 2); dims = 1)[1, :]
    pvec_out .= pvec .* (pvec .> 0)
    return pvec_out
end

InterCensminusLogLik(pvec, A) = -sum(log.(A * pvec))

function gen_problem_intercens!(par, spec, draw)
    Imat = rcopy(GenerateInterCensData(2000, 5))
    A = rcopy(Aintmap(Imat[:, 1], Imat[:, 2]))
    B = similar(A)
    n_unique = size(A, 2)

    par.lower = zeros(n_unique) # We put it here to adjust it to the size of the problem

    return (
        f         = pvec -> InterCensminusLogLik(pvec, A),
        m!        = (pvec_out, pvec_in) -> InterCensEM!(pvec_out, pvec_in, A, B),
        x_in      = ones(n_unique) / n_unique, 
        check_res = pvec -> InterCensminusLogLik(pvec, A))
end

function modif_par_intercens!(par)
    # acx options
    par.σ_min     = 1
    par.buffer    = 0.001
    par.check_obj = true

    #qnaam options
    par.non_monotone = true # Also valid for daarem_base_objfn

    #general options
    par.discrep_answers = ∞
    par.freq_display    = 1
    par.title           = "Interval censoring"
    par.algos           = [1, 2, 3, 4, 21]
    return par
end

if @isdefined modif_param_dict
    modif_param_dict["intercens"] = modif_par_intercens!
    gen_problem_dict["intercens"] = gen_problem_intercens!
end
"""
    This script generates the functions needed to perform
    high-dimensional regressions, using the algorithm of Gaure (2013)

    Notes: 
    - solve_ap implements Gaure's algorithm (with alternating projections) and 
      returns the OLS estimates.
    - solve_acx implements Gaure's algorithm with alternating projections
      accelerated by ACX and returns the OLS estimates.
    - run_lsmr calls FixedEffectModels.jl (only on Linux)

    Reference
    Gaure, S. (2013). OLS with multiple high dimensional category variables. 
    Computational Statistics and Data Analysis 66: 8–18.
"""

using DataFrames, FixedEffectModels, CSV, BenchmarkTools, LinearAlgebra, 
    Statistics, MuladdMacro

@inline _mod1(x, m) = mod(x - 1, m) + 1

function set_views(x :: Vector{Float64}, cats :: Vector{Int64})

    views = SubArray{Float64, 1, Vector{Float64}, Tuple{UnitRange{Int64}}, true}[]
    start_range = 1
    for i_obs ∈ eachindex(cats[1:end - 1])
        if cats[i_obs + 1] != cats[i_obs]
            push!(views, view(x,start_range:i_obs))
            start_range = i_obs + 1
        end
    end
    push!(views, view(x, start_range:length(cats)))
    return views
end

function set_views(x :: Vector{Float64}, cats :: Vector{Int64}, reorder :: Vector{Int64})

    views = SubArray{Float64, 1, Vector{Float64}, Tuple{Vector{Int64}}, false}[]
    start_range = 1
    for i_obs ∈ 1:length(cats) - 1
        if cats[i_obs + 1] != cats[i_obs]
            push!(views, view(x, reorder[start_range:i_obs]))
            start_range = i_obs + 1
        end
    end
    push!(views, view(x, reorder[start_range:end]))
    return views
end

function set_all_views(df :: DataFrame, groups :: Vector{Symbol})
    x = Vector{Float64}(undef, size(df,1))
    sort1 = sortperm(df[!,groups[1]])
    groups_sorted = df[!,groups[1]][sort1]
    views1 = set_views(x, groups_sorted)
    tot_cats = length(views1)

    other_views = Vector{SubArray{Float64, 1, Vector{Float64}, Tuple{Vector{Int64}}, false}}[]
    sort_view = Vector{Int64}(undef, length(x))
    for gr ∈ groups[2:end]
        groups_sorted .= df[!,gr]
        sort_view .= sortperm(groups_sorted)
        groups_sorted .= groups_sorted[sort_view]
        push!(other_views, set_views(x, groups_sorted, sort_view))
        tot_cats += length(other_views)
    end
    return x, sort1, views1, other_views, tot_cats
end

function demean(views)
    for v ∈ views
        v .-= sum(v)/length(v)
    end
end

function demean_all(
    views1 :: Vector{SubArray{Float64, 1, Vector{Float64}, 
        Tuple{UnitRange{Int64}}, true}}, 
    otherViews :: Vector{Vector{SubArray{Float64, 1, Vector{Float64}, 
        Tuple{Vector{Int64}}, false}}}
)

    demean(views1)
    for views ∈ otherViews
        demean(views)
    end
end

function compute_σ_ΔΔ(xs :: Vector{Vector{Float64}}, x :: Vector{Float64}, p :: Int64)

    ΔΔ = ΔᵃΔᵇ = ΔᵇΔᵇ = 0
    if p == 1 # If no acceleration
        @inbounds for i ∈ eachindex(x)
            ΔF = x[i] - xs[1][i]
            ΔΔ += ΔF * ΔF
        end
        return 0, ΔΔ
    elseif p == 2
        @inbounds for i ∈ eachindex(x)
            Δ¹ = xs[2][i] - xs[1][i]
            ΔF = x[i] - xs[2][i]
            Δ² = ΔF - Δ¹
            ΔΔ += ΔF * ΔF
            ΔᵃΔᵇ += Δ¹ * Δ²
            ΔᵇΔᵇ += Δ² * Δ²
        end
    else
        @inbounds for i ∈ eachindex(x)
            ΔFF = x[i] - xs[3][i]
            @muladd Δ² = xs[3][i] - 2xs[2][i] +  xs[1][i]
            @muladd Δ³ = x[i] - 3xs[3][i] + 3xs[2][i] - xs[1][i]
            ΔΔ += ΔFF * ΔFF
            ΔᵃΔᵇ += Δ² * Δ³
            ΔᵇΔᵇ += Δ³ * Δ³
        end
    end
    return max(abs(ΔᵃΔᵇ) / ΔᵇΔᵇ), ΔΔ
end

@inline function extrapolate!(
    x :: Vector{Float64}, xs :: Vector{Vector{Float64}}, σ :: Float64, p :: Int64
)

    σ² = σ * σ
    if p == 2
        @muladd c1 = 1 - 2σ + σ²
        @muladd c2 = 2σ - 2σ²
        @muladd @. x = c1 * xs[1] + c2 * xs[2] + σ² * x
    else
        σ³ = σ² * σ
        @muladd c1 = 1 - 3σ + 3σ² -  σ³
        @muladd c2 = 3σ - 6σ² + 3σ³
        @muladd c3 = 3σ² - 3σ³
        @muladd @. x = c1 * xs[1] + c2 * xs[2] + c3 * xs[3] + σ³ * x
    end
end

function acx!(
    x :: Vector{Float64}, xs :: Vector{Vector{Float64}}, 
    views1 :: Vector{SubArray{Float64, 1, Vector{Float64}, 
        Tuple{UnitRange{Int64}}, true}}, 
    otherViews :: Vector{Vector{SubArray{Float64, 1, Vector{Float64}, 
        Tuple{Vector{Int64}}, false}}},
    orders :: Vector{Int64}
)

    i_ord = 0
    maps = 0
    converged = false
    while !converged
        i_ord += 1
        io = _mod1(i_ord, length(orders))
        p = orders[io]
        for i ∈ 1:p
            xs[i] .= x
            demean_all(views1, otherViews)
            maps += 1
        end
        σ, ΔΔ = compute_σ_ΔΔ(xs, x, p)
        if ΔΔ < 1e-8^2; converged = true end
        if p > 1 && !converged extrapolate!(x, xs, σ, p) end
    end
    return maps
end

function ols(y, x, tot_cats)
    xx = x'x
    β  = xx \ x'y
    resid  = y .- x * β
    V = (resid ⋅ resid) / (length(y) - tot_cats) * inv(xx) # The degrees of freedom may not be exact
    return β, V
end

function reg_acx(df, y, covariates, groups; orders = [3,3,2])
    x, sort1, views1, other_views, tot_cats = set_all_views(df, groups)
    xs = [similar(x) for i ∈ 1: maximum(orders)]
    nmaps = 0

    covariates_net = Array{Float64,2}(undef,size(df,1),length(covariates))
    for i ∈ eachindex(covariates)
        x .= df[!, covariates[i]][sort1]
        nmaps += acx!(x, xs, views1, other_views, orders)
        covariates_net[:, i] .= x
    end

    x .= df[!, y][sort1]
    nmaps += acx!(x, xs, views1, other_views, orders)

    return ols(x, covariates_net, tot_cats)..., nmaps / (length(covariates) + 1)
end

df_all = DataFrame(CSV.File("col_regfile09.csv"))
df_short = df_all[df_all[!,:distw] .≤ 9876.24, :] #quantile(df.distw,0.75)

run_lsmr(df) = reg(df, @formula(ln_trade ~ col_cur + fe(expImp) + fe(expYear) + 
    fe(impYear)))

alt_proj_acx(df, orders) = reg_acx(df, :ln_trade, [:col_cur], 
    [:expImp, :impYear, :expYear]; orders)

alt_proj(df) = reg_acx(df, :ln_trade, [:col_cur], 
    [:expImp, :impYear, :expYear]; orders = [1])

function gen_problem(draw)
        return (title = "High-dimensional fixed-effects regression", f = ∅)
end

gen_problem_altproj(par, spec, draw) = (f = nothing, df = [df_all, df_short][spec])

function modif_par_altproj!(par)
    if Sys.iswindows() 
        @warn "In Windows, FixedEffectModels has a bug and must be ommitted."
        par.algos = [11, 12, 13, 14]
    else
        par.algos = [11, 12, 13, 14, 15]
    end

    par.title = "High-dimensional fixed-effects regression"
    par.ms = false
    par.ndraws = 1
    par.nruns = 100 # To take the median time (but will effectively be reduced to 5 runs since they take long).
    par.show_plot = false
    par.freq_display = 1	
    return par
end

if @isdefined modif_param_dict
    modif_param_dict["altproj"] = modif_par_altproj!
    gen_problem_dict["altproj"] = gen_problem_altproj
    nspecs_dict["altproj"]      = 2
end
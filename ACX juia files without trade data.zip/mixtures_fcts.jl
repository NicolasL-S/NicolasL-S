"""
    Defines functions and parameters for the Poisson admixture application
"""

freq = [162, 267, 271, 185, 111, 61, 27, 8, 3, 1] # The data
∑_freq = sum(freq)

function minus_ll_mixt(x)
   p, μ₁, μ₂ = x
    if p < 0 || p > 1 || μ₁ < 0 || μ₂ < 0
        return Inf
    else
        inv_exp_μ₁ = exp(-μ₁)
        inv_exp_μ₂ = exp(-μ₂)
        yfact = μ₁expy = μ₂expy = 1
        l = 0
        for y = 1:length(freq)
            l += freq[y] * log((p * inv_exp_μ₁ * μ₁expy + 
                          (1 - p) * inv_exp_μ₂ * μ₂expy) / yfact)
            yfact *= y
            μ₁expy *= μ₁
            μ₂expy *= μ₂
        end
    end
    return -l
end

function map_mixt!(x_out, x_in)
   p, μ₁, μ₂ = x_in
   i = 0:length(freq) - 1
    inv_exp_μ₁ = exp(-μ₁)
    inv_exp_μ₂ = exp(-μ₂)
   ∑_freq_z₁ = ∑_freq_z₂ = ∑_freq_y_z₁ = ∑_freq_y_z₂ = 0
    μ₁expy = μ₂expy = 1
   for i in 1:length(freq)
      y = i - 1
      q = p * inv_exp_μ₁ * μ₁expy
        z = q / (q + (1 - p) * inv_exp_μ₂ * μ₂expy)
      ∑_freq_z₁   += freq[i] * z
      ∑_freq_z₂   += freq[i] * (1 - z)
      ∑_freq_y_z₁ += y * freq[i] * z
        ∑_freq_y_z₂ += y * freq[i] * (1 - z)
        μ₁expy *= μ₁
        μ₂expy *= μ₂
    end
    x_out .= [∑_freq_z₁ / ∑_freq, ∑_freq_y_z₁ / ∑_freq_z₁, ∑_freq_y_z₂ / ∑_freq_z₂]
    return x_out
end

function gen_problem_mixtures(par, spec, draw)
    return (
        f         = minus_ll_mixt, 
        m!        = map_mixt!,
        x_in      = [0.05 + 0.9rand(), 20rand(), 20rand()], 
        check_res = minus_ll_mixt)
end

function modif_par_mixtures!(par)
    # acx options
    par.lower = [0.0, 0.0, 0.0]
    par.upper = [1.0, Inf, Inf]
    par.stabilize = true
    par.buffer = 0.2

    par.title = "Poisson mixtures"
    par.ms    = true
    par.algos = [1, 2, 3, 4, 9, 19]
    par.nparams = 3
    return par
end

if @isdefined modif_param_dict
    modif_param_dict["mixtures"] = modif_par_mixtures!
    gen_problem_dict["mixtures"] = gen_problem_mixtures
end
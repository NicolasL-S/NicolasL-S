"""
    Example_linear_model reproduces the linear example of Barzilai and 
    Borwein (1988), solving with the Barzilai-Borwein method, the Cauchy-
    Barzilai-Borwein method of Raydan and Svaiter (2002) and the ACX 2 and
    ACX 3,2. It generates Figure 1.

    References

    Barzilai, J. and Borwein, J. (1988). Two-point step size gradient methods. IMA Journal
        of Numerical Analysis 8: 141–148.
    Raydan, M. and Svaiter, B. (2002). Relaxed steepest descent and Cauchy-Barzilai-
        Borwein method. Computational Optimization and Applications 21: 155–167.
"""

# Note: due to scale not working automatically, exporting must be done manually.

using LinearAlgebra, LaTeXStrings, Quadmath
include("Constants.jl")
include("main.jl")
include("no_accel.jl")

function main_linear()
    Q = Diagonal([20, 10, 2, 1])
    dim = size(Q,1)
    d = zeros(dim)
    x_in = Float128.(zeros(dim))
    b = ones(dim)
    sol = Q\b
    x_show = 2
    data = [x_in[:],[0]]
    tol = 1e-8

    function map_lin!(x_out, x_in, A, b)
        x_out .= x_in .- (A*x_in .- b)
    end

    function map_steepest!(x_out, x_in, A, b)
        r = b .- A * x_in
        α = r'r  / (r' * (A * r))
        x_out .= x_in .+ α * r
    end

    function BB(x_in, A, b; max_maps = 10000, tol = 1e-8)
        n_iter = 0
        x = x_in[:]
        x_old = x_in[:]
        g = A*x_in .- b
        g_old = g[:]
        for i ∈ 1:max_maps
            n_iter += 1
            Δg = g - g_old
            Δx = x - x_old
            den = Δg ⋅ Δg
            num = Δg ⋅ Δx
            den > 0 ? α = num / den : α = 1
            x_old .= x
            g_old .= g
            x .-= α * g
            g = A*x .- b
            if norm(g, 2) <= tol; return x, n_iter end
        end
    end
    
    function CBB(x_in, A, b; max_maps = 10000, tol = 1e-8)
        n_iter = 0
        x = x_in[:]
        g = similar(x)
        h = similar(x)
        for i ∈ 1:max_maps
            n_iter += 1
            g .= A * x .- b
            if norm(g, 2) <= tol; return x, n_iter end
            h .= A * g
            t = (h ⋅ g) / (h ⋅ h)
            @. x += -2 * t * g + t^2 * h
        end
    end

    println("\nSteepest descent")
    _, m = no_accel(x_in, (x_out, x_in) -> map_steepest!(x_out, x_in, Q, b); verb = 0, tol = 1e-100)
    println("Converged after ", (m-1)*2, " maps.")

    println("\nBB")
    _, n_iter = BB(x_in, Q, b; tol)
    println("Converged after ", n_iter, " maps.")

    println("\nCBB")
    _, n_iter = CBB(x_in, Q, b; tol)
    println("Converged after ", (n_iter-1)*2, " maps.")

    println("\n",algo_names[1][1])
    res = speedmapping(x_in; m! = (x_out, x_in) -> map_lin!(x_out, x_in, Q, b), 
        orders = [2], store_info = true, tol, Lp = 2)

    println("Converged after ", res.maps-1, " maps.")
    
    psAll = res.info.p
    xs = reshape(vcat(res.info.x'...),length(res.info.x),length(res.info.x[1]))[psAll .!= 1,:]
    ps = psAll[psAll .!= 1]
    e = max.(abs.(broadcast(-, xs, sol')), 1e-200)

    # A predefined plot
    plt = plot(bg=:white, size = sizePlot, linewidth = linewidth, legendfontsize=fsl,
        xtickfontsize = small_font, ytickfontsize = small_font, yguidefontsize=fs, 
        xguidefontsize=fs, foreground_color_grid = lGrey, 
        foreground_color_legend = lGrey, markerstrokecolor = nothing);

    color1, shape1, style1 = algo_lines[1]
    color2, shape2, style2 = algo_lines[2]
    color3, shape3, style3 = algo_lines[3]

    plot!(e[:,1], e[:,x_show], linecolor = color1, label = algo_names[1][2], 
        linestyle = style1, linewidth = linewidth)

    scatter!(e[2:end,1], e[2:end,x_show], markersize = markersize, 
        markershape = shape1, markercolor = :white, label = "Square. extr.", 
        markerstrokecolor = color1, markerstrokewidth = linewidth)

    data = [x_in[:],[0]]
    println("\n",algo_names[2][1])
    res = speedmapping(x_in; m! = (x_out, x_in) -> map_lin!(x_out, x_in, Q, b), 
        orders = [3,2], store_info = true, tol, Lp = 2)
    
    println("Converged after ", res.maps - 1, " maps.")

    psAll = res.info.p
    xs = reshape(vcat(res.info.x'...),length(res.info.x),length(res.info.x[1]))[psAll .!= 1,:]
    ps = psAll[psAll .!= 1]
    e = max.(abs.(broadcast(-,xs,sol')),1e-50)

    plot!(e[:,1], e[:,x_show], linecolor = color2, label = algo_names[2][2], linestyle = style2, linewidth = linewidth)
    scatter!(e[ps .== 3,1], e[ps .== 3,x_show], markersize = markersize, 
        markershape = shape3, markercolor = :white, label = "Cubic extr.", 
        markerstrokecolor = color3, markerstrokewidth = linewidth)
    scatter!(e[ps .== 2,1], e[ps.== 2 ,x_show], 
        markersize = markersize, markershape = shape1, legend = (0,0.65),
        markercolor = :white, label = "Square extr.", markerstrokecolor = color1,
        xlabel = L"|e_1|", ylabel = L"|e_2|", xscale = :log10, yscale = :log10, 
        xlims = (1e-18, 1e0), ylims = (1e-18, 1e0), linewidth = linewidth, markerstrokewidth = linewidth)
    println("Note to get axes with appropriate scale: In the figure window click on the button Edit axis, curve and image parameters. Set both x and y axes to log.")
end

main_linear()

# Note: one matrix product A*x corresponds to 1 gradient evaluation
# Therefore, steepest descent requires 2 per iteration, BB requires 1 per iteration
# We remove the last iteration from every algorithm to discount the extra evaluations to measure convergence
"""
	DampingFind is adapted from the R package "daarem" v. 0.5 by 
	Lepage-Saucier (2021). Useless lines were commented.
"""

function DampingFind(uy_sq, dvec, aa, κ, sk, Ftf; λ_start=nothing,
                        r_start=nothing, maxit=10)
	## uy_sq is a vector whose jth component (U^t*y)^2
	## d_sq is a vector whose jth component is d_j^2.
	## (aa, kappa, sk) - parameters in determining delta_k
	## Ftf = F_{k}^T f_{k}
	##
	## Output: value of penalty term such that (approximately)
	## .       || beta.ridge ||^2/||beta.ols||^2 = delta_{k}^{2}, with 0 < target < 1.
	
	if isnothing(λ_start) || isnan(λ_start)
		λ_start = 100
	end
	if isnothing(r_start) || isnan(r_start)
		r_start = 0
	end
	if sum(dvec .== 0.0) > 0
		ind = dvec .> 0
		dvec = dvec[ind]
		display(uy_sq)
		display(ind)
		uy_sq = uy_sq[ind]
		## what about if dvec has length 1?
	end
	pow = κ - sk
	target = exp(-0.5*log1p(aa^pow))  ### This is sqrt(delta_k)
	#d_sq = pmax(dvec*dvec, 1e-7)  ## in case the least-squares problem is very poorly conditioned
	d_sq = dvec .* dvec
	βhat_ls_norm = sqrt(sum(uy_sq ./ d_sq))
	vk = target*βhat_ls_norm

	if vk == 0
		## the norm of the betas is zero, so the value of λ shouldn't matter
		return λ_start, r_start
	end

	### Initialize λ and lower and upper bounds
	λ = λ_start - r_start / vk
	LL = (βhat_ls_norm * (βhat_ls_norm - vk)) / sum(uy_sq ./ (d_sq .* d_sq))
	UU = Ftf / vk

	## Compute lstop and ustop
	pow_low = pow + 0.5
	pow_up = pow - 0.5
	l_stop = exp(-0.5*log1p(aa^pow_low))
	u_stop = exp(-0.5*log1p(aa^pow_up))

	# NL-S Preallocating to speed up
	d_λ, d_prime, d_u = (similar(dvec), similar(dvec), similar(dvec))
	s_norm = φ_ratio = 1 # NL-S For declaration purposes only
	### Start iterations
	for k ∈ 1:maxit
		### Check if λ is inside lower and upper bounds
		if λ <= LL || λ >= UU
			λ = max(.0001*UU, sqrt(LL*UU))
		end
		### Evaluate ||s(λ)|| and \φ(λ)/φ'(λ)
		d_λ .= (dvec ./ (d_sq .+ λ)).^2
		d_prime .= d_λ ./ (d_sq .+ λ)
		s_norm = sqrt(sum(uy_sq .* d_λ))
		φ_val = s_norm - vk
		φ_der = -sum(uy_sq .* d_prime) / s_norm
		φ_ratio = φ_val / φ_der

		# d_u = (dvec ./ (d_sq .+ LL)).^2 # NL-S This doesn't do anything
		# s_up = sqrt(sum(uy_sq .* d_u)) # NL-S This doesn't do anything
		### Initial Lower bound is not correct

		### Check convergence
		if s_norm <= u_stop * βhat_ls_norm && s_norm >= l_stop * βhat_ls_norm
			break
		end
		
		### If not converged, update lower and upper bounds
		for φ_vali ∈ φ_val
			if φ_vali < 0; UU = λ end
		end
		LL = max.(LL, λ .- φ_ratio)

		### Now update λ
		λ -= (s_norm * φ_ratio) / vk
		# bb = (s_norm * φ_ratio) / vk # NL-S This doesn't do anything
	end
	return λ, s_norm * φ_ratio
end
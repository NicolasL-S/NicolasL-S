using RCall
R"library(daaremtest)"

function mvt_emj(x_in, y, ν; KTW = false)
    n, p = size(y)
    y_dem = y .- x_in[1:p]'
    u = (ν + p) ./ (ν .+ sum(y_dem .* 
        (y_dem / reshape(x_in[p + 1:end],(p, p))); dims = 2))
    sum_w = sum(u)
    μ = vec(y'u ./ sum_w)
    y_dem .= (y .- μ')
    Σ = zeros(p, p)
    KTW ? u ./= sum_w : u ./= n # Only difference between EM and PXEM
    for i ∈ 1:p, j ∈ i:p
        Σ[i, j] = sum(y_dem[:, i] .* y_dem[:, j] .* u)
    end
    return [μ; vec(Symmetric(Σ))]
end

function mvt_negloglik_vectj(x_in, y, ν) 
    n, p = size(y)
    y_dem = y .- x_in[1:p]'
    V = reshape(x_in[p + 1:end], (p, p))
    detV = det(V)
    return if detV < 0 
        return Inf
    else
        return n / 2 * log(detV) + (ν + p) / 2 * 
            sum(log.(ν .+ sum(y_dem .* (y_dem / V); dims = 2)))
    end
end

function gen_problem_mvt!(par, spec, draw)
    R"""
        df <- 1
        n <- 200
        ndim <- 10
        mu <- rep(0,ndim)
        V <- matrix(round(rnorm(ndim^2), 1), ndim, ndim) # SPD covariance matrix
        V <- V %*% t(V)
        y <- rmvt.sim(n, mu, V, df) # simulate data from a multivariate t-distn 
        mu0 <- apply(y, 2, mean)
        V0 <- array(apply(t(t(y) - mu0), 1, function(x){outer(x, x)}),dim=c(ndim, ndim, n))
        V0 <- apply(V0, c(1, 2), function(x)mean(x))	
    """
    @rget y
    @rget df
    @rget mu0
    @rget V0

    function map_mvt!(x_out, x_in)
        x_out .= mvt_emj(x_in, y, df; KTW = spec == 1)
    end

    par.title = "Multivariate t distribution, " * ["PXEM", "EM"][spec]

    return (
        f         = param -> mvt_negloglik_vectj(param, y, df),
        m!        = map_mvt!,
        x_in      = [mu0; vec(V0)], 
        check_res = param -> mvt_negloglik_vectj(param, y, df))
end

function modif_par_mvt!(par)
    par.ms               = true
    par.algos            = [1, 2, 3, 4, 5, 9, 21]
    return par
end

if @isdefined modif_param_dict
    modif_param_dict["mvt"] = modif_par_mvt!
    gen_problem_dict["mvt"] = gen_problem_mvt!
    nspecs_dict["mvt"]      = 2
end
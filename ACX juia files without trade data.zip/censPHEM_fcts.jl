using RCall

function InterCensPHEMj!(x_out, x_in, ncoefs, d1, d2, d3, bLi, bRi, Xp, exp_xb0Xp, EZil, EWil)
    g0 = x_in[ncoefs + 1:end]
    ## The model parameters are b0 and g0
    L = length(g0)
    N = length(d1)
    exp_xb0 = exp.(Xp * x_in[1:ncoefs])
    EZil .= zeros(N, L) # Preallocated, may help
    EWil .= zeros(N, L) # Preallocated, may help
    dz = 1 .- exp.(-(bRi[d1, :] * g0) .* exp_xb0[d1])
    drL2 = bRi[d2, :] .- bLi[d2, :]
    dw = 1 .- exp.(-(drL2 * g0) .* exp_xb0[d2])
    EZil[d1 .== 1, :] = ((bRi[d1, :])' .* g0)' .* vec(exp_xb0[d1] ./ dz)
    EWil[d2 .== 1, :] = (drL2'         .* g0)' .* vec(exp_xb0[d2] ./ dw)
    Dil = EZil .+ EWil .* d2
    Dl = sum(Dil; dims = 1)
    Cil = (d1 .+ d2) .* bRi .+ d3 .* bLi

    diff1 = 1
    b01 = x_in[1:ncoefs]
    b11 = similar(b01)
    count = 0
    s2 = size(Xp, 2)
    deriv1 = Vector{eltype(Xp)}(undef, s2)
    deriv2 = Matrix{eltype(Xp)}(undef, s2, s2)
    #	exp_xb0Xp = Matrix{eltype(Xp)}(undef,length(exp_xb0),s2) # Prealllocating. It might help
    Fl = Matrix{eltype(Xp)}(undef, 1, size(Cil, 2))
    diff1 = diff1_old = Inf # added
    while(diff1 > 1e-7 && count < 100 && diff1 ≤ diff1_old) # added 3rd condifion
        exp_xb0 .= exp.(Xp * b01)
        exp_xb0Xp .= vec(exp_xb0) .* Xp
        Fl .= sum(Cil .* vec(exp_xb0); dims = 1)
        deriv1 .= (sum(Dil' * Xp; dims = 1) .- sum((Cil .* (exp_xb0 * (Dl ./ Fl)))' * Xp; dims = 1))[1, :]
        deriv2 .= exp_xb0Xp' * (Cil * (vec(Dl ./ Fl.^2) .* (Cil' * exp_xb0Xp))) - 
                     (vec(Cil * ((Dl ./ Fl.^2)[1, :] .* (Cil' * exp_xb0))) .* Xp)' * exp_xb0Xp
        try
            b11 .= b01 .- (deriv2 \ deriv1)
        catch
            b11 .= b01 .- pinv(deriv2) * deriv1
        end
        diff1_old = diff1
        diff1 = norm(b11 .- b01, Inf)
        b01 .= b11[:]
        count += 1
    end
    b1 = vec(b11[:])
    x_out .= [b1; vec(Dl[1, :] ./ (Cil' * exp.(Xp * b1)))]
end

function NegLogLikICRj(x_in, ncoefs, d1, d2, d3, bLi, bRi, Xp)
    exp_xb = exp.(Xp * x_in[1:ncoefs])
    expR = exp.(-(bRi * x_in[ncoefs + 1:end]) .* exp_xb)
    expL = exp.(-(bLi * x_in[ncoefs + 1:end]) .* exp_xb)
    alllk = (1 .- expR) .* d1 .+ (expL - expR) .* d2 .+ expL .* d3
    if sum(alllk .< 0) > 0 
        return Inf
    else
        return(-sum(log.(alllk)))
    end
end

R"""
    library(daaremtest)
    library(xtable)
    library(splines)
    library(splines2)
    library(PCDSpline)
"""

function gen_problem_censPHEM(par, spec, draw)
    R""" # Code from icr_timings.R
        nsub <- 2000
        icrdat <- GenerateICRData(nsub) # Generating the data
        equal <- TRUE
        n.int <- 3
        order <- 3
        g0 <- rep(1, (order + n.int))
        b0 <- rep(0, dim(icrdat$X)[2])
        t.s <- seq(min(icrdat$Y),max(icrdat$Y),length.out = 100)
        ### How to run
        icrdat$Li[icrdat$d1 == 1] <- icrdat$Ri[icrdat$d1 == 1]
        icrdat$Ri[icrdat$d3 == 1] <- icrdat$Li[icrdat$d3 == 1]
        ti <- c(icrdat$Li[icrdat$d1 == 0], icrdat$Ri[icrdat$d3 == 0])
        if (equal == TRUE) {
            ti.max <- max(ti) + 1e-05
            ti.min <- min(ti) - 1e-05
            knots <- seq(ti.min, ti.max, length.out = (n.int + 2))
        }
        if (equal == FALSE) {
            id <- seq(0, 1, length.out = (n.int + 2))
            id <- id[-c(1, (n.int + 2))]
            ti.max <- max(ti) + 1e-05
            ti.min <- min(ti) - 1e-05
            knots <- c(ti.min, quantile(ti, id), ti.max)
        }

        g0 <- rep(1, (order + n.int))
        b0 <- rep(0, dim(icrdat$X)[2])
        t.seq <-seq(min(icrdat$Y), max(icrdat$Y), length.out = 100)
        bRi <- t(Ispline(x = icrdat$Ri, order = order, knots = knots))
        bLi <- t(Ispline(x = icrdat$Li, order = order, knots = knots))
        bt  <- t(Ispline(x = t.seq, order = order, knots = knots))

        par0 <- c(b0, g0)
        ncoefs <- length(b0)
        pvec.init <- par0
        x_in <- pvec.init
        d1 <- icrdat$d1
        d2 <- icrdat$d2
        d3 <- icrdat$d3
        Xp <- icrdat$X
    """
    
    @rget x_in
    @rget ncoefs
    @rget d1
    @rget d2
    @rget d3
    @rget bLi
    @rget bRi
    @rget Xp
    exp_xb0Xp = similar(Xp) # Preallocating
    N, L = size(bRi)
    EZil, EWil = (zeros(N, L), zeros(N, L))
    d1 = (d1 .== 1)
    d2 = (d2 .== 1.0)

    par.nparams = length(x_in)
    return (
        f         = x -> NegLogLikICRj(x, ncoefs, d1, d2, d3, bLi, bRi, Xp),
        m!        = (x_out, x_in) -> InterCensPHEMj!(x_out, x_in, ncoefs, d1, d2, 
                    d3, bLi, bRi, Xp, exp_xb0Xp, EZil, EWil),
        x_in      = x_in, 
        check_res = x -> NegLogLikICRj(x, ncoefs, d1, d2, d3, bLi, bRi, Xp))
end

function modif_par_censPHEM!(par)
    #ACX options
    par.σ_min           = 1.0

    #general options
    par.title           = "Proportional Hazards Reg. With Interval Censoring"
    par.algos           = [1, 2, 3, 4, 20]
    par.freq_display    = 1
    par.tol             = 1e-3
    par.discrep_answers = 2
    return par
end

if @isdefined modif_param_dict
    modif_param_dict["censPHEM"] = modif_par_censPHEM!
    gen_problem_dict["censPHEM"] = gen_problem_censPHEM
end
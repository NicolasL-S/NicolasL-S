"""
    CUTEst functions and parameters, excluding many problems ex-ante based on 
    several criteria. The display_results and display_stats functions are also
    redefined.
"""

using CUTEst, NLPModels, BenchmarkTools
include("Constants.jl")

CUTEst_problems = [
    "ARGLBLE"   , "ARGLCLE"   , "ARGLINA"   , "ARGLINB"   , "ARGLINC"   , 
    "ARGTRIGLS" , "ARWHEAD"   , "BA-L16LS"  , "BA-L1LS"   , "BA-L21LS"  , 
    "BA-L49LS"  , "BA-L73LS"  , "BDQRTIC"   , "BOX"       , "BOXPOWER"  ,
    "BROWNAL"   , "BROYDN3DLS", "BROYDN7D"  , "BROYDNBDLS", "BRYBND"    ,
    "CHAINWOO"  , "CHNROSNB"  , "CHNRSNBM"  , "COATING"   , "COATINGNE" , 
    "COSINE"    , "CRAGGLVY"  , "CURLY10"   , "CURLY20"   , "CURLY30"   , 
    "CYCLOOCFLS", "DECONVU"   , "DIAMON2DLS", "DIAMON3DLS", "DIXMAANA"  , 
    "DIXMAANB"  , "DIXMAANC"  , "DIXMAAND"  , "DIXMAANE"  , "DIXMAANF"  ,
    "DIXMAANG"  , "DIXMAANH"  , "DIXMAANI"  , "DIXMAANJ"  , "DIXMAANK"  , 
    "DIXMAANL"  , "DIXMAANM"  , "DIXMAANN"  , "DIXMAANO"  , "DIXMAANP"  , 
    "DIXON3DQ"  , "DMN15103LS", "DMN15332LS", "DMN15333LS", "DMN37142LS", 
    "DMN37143LS", "DQDRTIC"   , "DQRTIC"    , "EDENSCH"   , "EG2"       ,
    "EIGENALS"  , "EIGENBLS"  , "EIGENCLS"  , "ENGVAL1"   , "ERRINROS"  , 
    "ERRINRSM"  , "EXTROSNB"  , "FLETBV3M"  , "FLETCBV2"  , "FLETCBV3"  , 
    "FLETCHBV"  , "FLETCHCR"  , "FMINSRF2"  , "FMINSURF"  , "FREUROTH"  , 
    "GENHUMPS"  , "GENROSE"   , "HILBERTB"  , "HYDC20LS"  , "INDEF"     ,
    "INDEFM"    , "INTEQNELS" , "JIMACK"    , "KSSLS"     , "LIARWHD"   , 
    "LUKSAN11LS", "LUKSAN12LS", "LUKSAN13LS", "LUKSAN14LS", "LUKSAN15LS", 
    "LUKSAN16LS", "LUKSAN17LS", "LUKSAN21LS", "LUKSAN22LS", "MANCINO"   , 
    "MNISTS0LS" , "MNISTS5LS" , "MODBEALE"  , "MOREBV"    , "MSQRTALS"  ,
    "MSQRTBLS"  , "NCB20"     , "NCB20B"    , "NONCVXU2"  , "NONCVXUN"  , 
    "NONDIA"    , "NONDQUAR"  , "NONMSQRT"  , "OSCIGRAD"  , "OSCIPATH"  , 
    "PENALTY1"  , "PENALTY2"  , "PENALTY3"  , "POWELLSG"  , "POWER"     , 
    "QING"      , "QUARTC"    , "SBRYBND"   , "SCHMVETT"  , "SCOSINE"   ,
    "SCURLY10"  , "SCURLY20"  , "SCURLY30"  , "SENSORS"   , "SINQUAD"   , 
    "SPARSINE"  , "SPARSQUR"  , "SPIN2LS"   , "SPINLS"    , "SPMSRTLS"  , 
    "SROSENBR"  , "SSBRYBND"  , "SSCOSINE"  , "STRTCHDV"  , "TESTQUAD"  , 
    "TOINTGOR"  , "TOINTGSS"  , "TOINTPSP"  , "TOINTQOR"  , "TQUARTIC"  , 
    "TRIDIA"    , "TRIGON1"   , "TRIGON2"   , "VARDIM"    , "VAREIGVL"  , 
    "WOODS"     , "YATP1CLS"  , "YATP2CLS"  , "YATP2SQ"   
]

params = [
    ("BROYDN3DLS", "N=500"  ), ("BROYDN7D", "N=50"  ), ("CHAINWOO", "N=100" ), 
    ("CURLY10"   , "N=1000"), ("CURLY20"   , "N=100"  ), ("CURLY30" , "N=100" ),
    ("CYCLOOCFLS", "N=100" ), ("DIXON3DQ"  , "N=1000" ), ("GENHUMPS", "N=500" ), 
    ("FLETCBV2"  , "N=100" ), ("HILBERTB"  , "N=50"   ), ("INDEF"   , "N=100" ), 
    ("MODBEALE"  , "N=100" ), ("NCB20"     , "N=100"  ), ("NONCVXU2", "N=100" ), 
    ("NONMSQRT"  , "N=49"  ), ("SBRYBND"   , "N=50"   ), ("SCOSINE" , "N=100" ), 
    ("SCURLY10"  , "N=100" ), ("SCURLY20"  , "N=100"  ), ("SCURLY30", "N=100" ), 
    ("SENSORS"   , "N=100" ), ("SSBRYBND"  , "N=1000" ), ("TRIGON2" , "N=1000")
]

name_para = [params[i][1] for i ∈ 1:length(params)]
para_para = [params[i][2] for i ∈ 1:length(params)]

tol6 = [          "DIXMAANM"  , "DIXMAANI"  , "DQRTIC"    , "FMINSRF2"  , 
    "FMINSURF"  , "POWELLSG"  , "QUARTC"    , "TQUARTIC"  ]
tol7 =          [ "BOXPOWER"  , "NONDQUAR"  ]
tol8 =          [ "DIXON3DQ"  , "ERRINRSM"  , "CURLY20"   , "CURLY30"   ]
tols = [tol6, tol7, tol8]

zero_∇ =        [ "ARGLBLE"   , "ARGLCLE"   , "COATINGNE" , "YATP2SQ"   ]
discrepant_result = [
    "BROYDN7D"  , "CHAINWOO"  , "DIAMON2DLS", "DIAMON3DLS", "ERRINROS"  , 
    "INDEFM"    , "LUKSAN12LS", "LUKSAN14LS", "LUKSAN22LS", "MNISTS0LS" , 
    "MNISTS5LS" , "MODBEALE"  , "NCB20"     , "NONCVXU2"  , "SCOSINE"   , 
    "SENSORS"   , "SSCOSINE"  , "TRIGON2"   
]
too_long = [
    "BA-L16LS"  , "BA-L21LS"  , "BA-L49LS"  , "BA-L73LS"  , "CYCLOOCFLS", 
    "DMN15103LS", "DMN15332LS", "DMN15333LS", "DMN37142LS", "DMN37143LS", 
    "EIGENALS"  , "EIGENBLS"  , "EIGENCLS"  ,"FLETBV3M"   , "FLETCBV3"  ,  
    "FLETCHBV"  , "HYDC20LS"  , "INDEF"     , "JIMACK"    , "NONMSQRT"  , 
    "NONCVXUN"  , "SPINLS"    , "SBRYBND"   , "SCURLY10"  , "SCURLY20"  , 
    "SCURLY30"  
]
too_short =    ["ARGLINA"]

for exclude ∈ [zero_∇; discrepant_result; too_long; too_short]
    deleteat!(CUTEst_problems, findall(x -> x == exclude, CUTEst_problems))
end

function display_stats_CUTEst(stats, good_draws, par; handle = nothing, draw = nothing)
    stats_names = ["Grad eval", "Obj eval", "sec", "Conv", "Minimum"]
    algonames = [algo_names[i][1] for i ∈ par.algos]
    handle === nothing ? println("\n" * par.title) : write(handle, "\n" * par.title * "\n")
    table_display(stats[draw, :, :]; rownames = algonames, 
                      colnames = stats_names, cornername = "Algorithm", 
                      n_chars  = [10,10,6,6,25], n_chars0 = 10, handle,
                      type_cols = [Float64, Float64, Float64, Bool, Float64])
end

# This overwrites display_result() in Run_examples
function display_results_CUTEst(stats, good_draws, name, par)
    io = open(path_output * "output_CUTEst.txt", "w")
    for draw ∈ eachindex(good_draws)
        if good_draws[draw]
            global p = gen_problem_CUTEst!(par, 1, draw)
            for handle ∈ (nothing, io)
                display_stats_CUTEst(stats, good_draws, par; handle, draw) 
                finalize(p.nlp)
            end
        end
    end
    close(io)
end

function gen_problem_CUTEst!(par, spec, draw)
    problem = CUTEst_problems[max(draw, 1)] # Using max to avoid the warmup call draw = 0
    index = findfirst(x -> x == problem, name_para)
    try # In case some previous problem was still open
        finalize(p.nlp)
    catch
    end

    if index === nothing		
        global nlp = CUTEstModel(problem)
    else
        global nlp = CUTEstModel(problem, "-param", para_para[index])
    end

    tolCUTEst = 1e-5
    for i ∈ 1:length(tols)
        if findfirst(x -> x == problem, tols[i]) !== nothing
            tolCUTEst = 10.0^(-5 - i)
        end
    end

    f_CUTEst(x) = obj(nlp, x)
    
    # To make sure that all algorithms stop with the exact same criterion

    function g_CUTEst!(∇, x)
        grad!(nlp, x, ∇)
        if norm(∇, Inf) ≤ tolCUTEst
            ∇ .*= 0
        end
        return ∇
    end

    par.title = "$problem, " * string(length(nlp.meta.x0)) * 
        " vars, Tol = $tolCUTEst, f(x₀) = " * string(f_CUTEst(nlp.meta.x0))

    return (
        f    = f_CUTEst, 
        g!   = g_CUTEst!,
        x_in = nlp.meta.x0,
        nlp  = nlp)
end

function modif_par_CUTEst!(par)
    par.nruns           = 100
    par.freq_display    = 1
    par.min_maps        = 5
    par.ndraws          = length(CUTEst_problems)
    par.display_stats   = display_stats_CUTEst
    par.display_results = display_results_CUTEst
    par.algos           = [1, 2, 3, 7, 8]
    return par
end

if @isdefined modif_param_dict
    modif_param_dict["CUTEst"] = modif_par_CUTEst!
    gen_problem_dict["CUTEst"] = gen_problem_CUTEst!
end

#=


ARGLINB, 200 vars, Tol = 1.0e-5, f(x₀) = 8.6512245099604e15 draw: 1 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:07
1: converged 2: converged 3: converged 4: converged 5: converged 

ARGLINB, 200 vars, Tol = 1.0e-5, f(x₀) = 8.6512245099604e15
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            19.0        9.0 0.0059   true          99.6254681664134 
ACX 3,2          59.0        9.0 0.0168   true         99.62546816557386 
ACX 3,3,2        81.0        9.0 0.0228   true         99.62546816878266 
L-BFGS           16.0       16.0 0.0057   true         99.62546816629416 
Conj Grad        10.0       10.0 0.0036   true         99.62546816813293 
Time left: 14 minutes, 20 seconds

ARGLINC, 200 vars, Tol = 1.0e-5, f(x₀) = 8.352671057963401e15 draw: 2 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:07
1: converged 2: converged 3: converged 4: converged 5: converged 

ARGLINC, 200 vars, Tol = 1.0e-5, f(x₀) = 8.352671057963401e15
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            51.0        9.0 0.0144   true        101.12547050871039 
ACX 3,2          68.0        9.0 0.0190   true        101.12547050621713 
ACX 3,3,2        36.0        9.0 0.0104   true        101.12547050672538 
L-BFGS           40.0       40.0 0.0141   true        101.12547050679507 
Conj Grad        36.0       39.0 0.0129   true        101.12547050692254 
Time left: 13 minutes, 32 seconds

ARGTRIGLS, 200 vars, Tol = 1.0e-5, f(x₀) = 66.331534046883 draw: 3 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:22
1: converged 2: converged 3: converged 4: converged 5: converged 

ARGTRIGLS, 200 vars, Tol = 1.0e-5, f(x₀) = 66.331534046883
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2          2109.0       10.0 1.0064   true    1.3772656703967902e-11 
ACX 3,2        1848.0       10.0 0.8726   true     8.393484786139301e-12 
ACX 3,3,2      1652.0       10.0 0.7787   true     2.399222619100429e-11 
L-BFGS         1440.0     1440.0 0.7655   true     8.207411074866842e-12 
Conj Grad       570.0     1134.0 0.3334   true    1.2012291209908874e-12 
Time left: 21 minutes, 18 seconds

ARWHEAD, 5000 vars, Tol = 1.0e-5, f(x₀) = 14997.0 draw: 4 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:06
1: converged 2: converged 3: converged 4: converged 5: converged 

ARWHEAD, 5000 vars, Tol = 1.0e-5, f(x₀) = 14997.0
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            11.0        9.0 0.0076   true    5.5500049001011575e-12 
ACX 3,2          14.0        9.0 0.0091   true      7.77000686014162e-12 
ACX 3,3,2        20.0        9.0 0.0122   true                       0.0 
L-BFGS           21.0       21.0 0.0154   true                       0.0 
Conj Grad        20.0       26.0 0.0159   true                       0.0 
Time left: 18 minutes, 34 seconds

BA-L1LS, 57 vars, Tol = 1.0e-5, f(x₀) = 127387.76409354944 draw: 5 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:01
1: converged 2: converged 3: converged 4: converged 5: converged 

BA-L1LS, 57 vars, Tol = 1.0e-5, f(x₀) = 127387.76409354944
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            41.0        7.0 0.0018   true     8.052151311285825e-19 
ACX 3,2          37.0        7.0 0.0017   true     9.209479204087724e-17 
ACX 3,3,2        38.0        7.0 0.0017   true    2.8897687062624905e-17 
L-BFGS           53.0       53.0 0.0034   true     6.011173952820811e-17 
Conj Grad        34.0       58.0 0.0027   true    2.4295172064976838e-17 
Time left: 15 minutes, 10 seconds

BDQRTIC, 5000 vars, Tol = 1.0e-5, f(x₀) = 1.129096e6 draw: 6 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:09
1: converged 2: converged 3: converged 4: converged 5: converged 

BDQRTIC, 5000 vars, Tol = 1.0e-5, f(x₀) = 1.129096e6
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           235.0        7.0 0.1553   true        20006.256878435706 
ACX 3,2         246.0        7.0 0.1594   true        20006.256878434775 
ACX 3,3,2       231.0        7.0 0.1491   true        20006.256878435666 
L-BFGS          139.0      139.0 0.1251   true        20006.256878432614 
Conj Grad       869.0     1439.0 0.8788   true         20006.25687843479 
Time left: 15 minutes

BOX, 10000 vars, Tol = 1.0e-5, f(x₀) = 0.0 draw: 7 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:13
1: converged 2: converged 3: converged 4: converged 5: converged 

BOX, 10000 vars, Tol = 1.0e-5, f(x₀) = 0.0
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           128.0       11.0 0.1790   true       -1864.5379265592046 
ACX 3,2         149.0       11.0 0.2052   true       -1864.5379265580123 
ACX 3,3,2        96.0       11.0 0.1350   true       -1864.5379265631543 
L-BFGS           16.0       16.0 0.0320   true       -1864.5379265548227 
Conj Grad        33.0       37.0 0.0671   true       -1864.5379265662652 
Time left: 15 minutes, 50 seconds

BOXPOWER, 20000 vars, Tol = 1.0e-7, f(x₀) = 176402.156206933 draw: 8 
┌ Warning: Exceeded time limit of 100 seconds.
└ @ Main ~/Dropbox/Principal/Projets/Fixed-point/Julia_FixedPoint/main.jl:448
┌ Warning: Exceeded time limit of 100 seconds.
└ @ Main ~/Dropbox/Principal/Projets/Fixed-point/Julia_FixedPoint/main.jl:448
Progress:  40%|██████████████████████████████████████████████▍                                                                     |  ETA: 0:05:00┌ Warning: Exceeded time limit of 100 seconds.
└ @ Main ~/Dropbox/Principal/Projets/Fixed-point/Julia_FixedPoint/main.jl:448
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:05:03
1: NOT converged 2: NOT converged 3: NOT converged 4: converged 5: converged 

BOXPOWER, 20000 vars, Tol = 1.0e-7, f(x₀) = 176402.156206933
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2             Inf        Inf    Inf  false    0.00026963654551697335 
ACX 3,2           Inf        Inf    Inf  false    0.00031637291718940454 
ACX 3,3,2         Inf        Inf    Inf  false     0.0003874195167923442 
L-BFGS           97.0       97.0 0.2420   true     8.368161530348073e-17 
Conj Grad       131.0      160.0 0.3584   true      1.889649467912318e-7 
Time left: 1 hour, 12 minutes, 3 seconds

BROWNAL, 200 vars, Tol = 1.0e-5, f(x₀) = 2.0099507480478287e6 draw: 9 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:01
1: converged 2: converged 3: converged 4: converged 5: converged 

BROWNAL, 200 vars, Tol = 1.0e-5, f(x₀) = 2.0099507480478287e6
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2             9.0       10.0 0.0016   true     1.4733240258689994e-9 
ACX 3,2          14.0       10.0 0.0023   true      1.475562125955964e-9 
ACX 3,3,2        12.0       10.0 0.0020   true     1.4755763966092019e-9 
L-BFGS           39.0       39.0 0.0070   true     1.4730193036430388e-9 
Conj Grad        28.0       30.0 0.0051   true     1.4733956627190252e-9 
Time left: 1 hour, 3 minutes, 44 seconds

BROYDN3DLS, 500 vars, Tol = 1.0e-5, f(x₀) = 511.0 draw: 10 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:01
1: converged 2: converged 3: converged 4: converged 5: converged 

BROYDN3DLS, 500 vars, Tol = 1.0e-5, f(x₀) = 511.0
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            41.0       11.0 0.0018   true     9.086384199375507e-12 
ACX 3,2          36.0       11.0 0.0016   true    3.4943323171459648e-12 
ACX 3,3,2        38.0       11.0 0.0017   true    3.0144423127028603e-12 
L-BFGS           72.0       72.0 0.0044   true     4.911586672931863e-12 
Conj Grad        35.0       67.0 0.0026   true     9.647789964219402e-12 
Time left: 56 minutes, 58 seconds

BROYDNBDLS, 5000 vars, Tol = 1.0e-5, f(x₀) = 124904.0 draw: 11 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:23
1: converged 2: converged 3: converged 4: converged 5: converged 

BROYDNBDLS, 5000 vars, Tol = 1.0e-5, f(x₀) = 124904.0
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           105.0        5.0 0.0839   true      3.17306285869728e-12 
ACX 3,2         116.0        5.0 0.0913   true     3.099758199426068e-11 
ACX 3,3,2       214.0        5.0 0.1667   true      5.12264010090261e-11 
L-BFGS          106.0      106.0 0.1125   true     2.127091248875539e-11 
Conj Grad        34.0       61.0 0.0428   true    1.6040443138266533e-11 
Time left: 54 minutes, 29 seconds

BRYBND, 5000 vars, Tol = 1.0e-5, f(x₀) = 124904.0 draw: 12 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:23
1: converged 2: converged 3: converged 4: converged 5: converged 

BRYBND, 5000 vars, Tol = 1.0e-5, f(x₀) = 124904.0
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           105.0        5.0 0.0840   true      3.17306285869728e-12 
ACX 3,2         116.0        5.0 0.0915   true     3.099758199426068e-11 
ACX 3,3,2       214.0        5.0 0.1669   true      5.12264010090261e-11 
L-BFGS          106.0      106.0 0.1128   true     2.127091248875539e-11 
Conj Grad        34.0       61.0 0.0428   true    1.6040443138266533e-11 
Time left: 52 minutes, 22 seconds

CHNROSNB, 50 vars, Tol = 1.0e-5, f(x₀) = 7635.839999999999 draw: 13 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:04
1: converged 2: converged 3: converged 4: converged 5: converged 

CHNROSNB, 50 vars, Tol = 1.0e-5, f(x₀) = 7635.839999999999
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2          4261.0        7.0 0.0226   true    1.1792344190290418e-11 
ACX 3,2        1109.0        7.0 0.0059   true    2.8359624890005354e-11 
ACX 3,3,2      1081.0        7.0 0.0058   true    3.1632818363159953e-13 
L-BFGS          552.0      552.0 0.0054   true    2.0501951807566576e-12 
Conj Grad       276.0      548.0 0.0038   true     2.046061453522594e-12 
Time left: 48 minutes, 19 seconds

CHNRSNBM, 50 vars, Tol = 1.0e-5, f(x₀) = 8633.49433156 draw: 14 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:03
1: converged 2: converged 3: converged 4: converged 5: converged 

CHNRSNBM, 50 vars, Tol = 1.0e-5, f(x₀) = 8633.49433156
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2          2304.0        8.0 0.0122   true     5.983768153694303e-13 
ACX 3,2        1414.0        8.0 0.0075   true     9.162911728450815e-12 
ACX 3,3,2      1153.0        8.0 0.0062   true    2.9970354189414106e-12 
L-BFGS          725.0      725.0 0.0070   true    1.3299256267925877e-12 
Conj Grad       224.0      444.0 0.0030   true    2.4190587620374783e-11 
Time left: 44 minutes, 45 seconds

COATING, 134 vars, Tol = 1.0e-5, f(x₀) = 14981.054583983307 draw: 15 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:01:23
1: converged 2: converged 3: converged 4: converged 5: converged 

COATING, 134 vars, Tol = 1.0e-5, f(x₀) = 14981.054583983307
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2        229216.0        8.0 7.4640   true         0.505499410413548 
ACX 3,2      101491.0        8.0 3.3090   true        0.5054994248287014 
ACX 3,3,2     60611.0        8.0 1.9703   true        0.5054992654801743 
L-BFGS        16450.0    16450.0 0.7812   true        0.5054986690409712 
Conj Grad      4909.0     9794.0 0.3055   true        0.5054986479290964 
Time left: 49 minutes, 10 seconds

COSINE, 10000 vars, Tol = 1.0e-5, f(x₀) = 8774.948036342494 draw: 16 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:15
1: converged 2: converged 3: converged 4: converged 5: converged 

COSINE, 10000 vars, Tol = 1.0e-5, f(x₀) = 8774.948036342494
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            20.0        8.0 0.0238   true                   -9999.0 
ACX 3,2          23.0        8.0 0.0268   true                   -9999.0 
ACX 3,3,2        24.0        8.0 0.0280   true                   -9999.0 
L-BFGS           27.0       27.0 0.0423   true                   -9999.0 
Conj Grad        14.0       21.0 0.0246   true                   -9999.0 
Time left: 46 minutes, 54 seconds

CRAGGLVY, 5000 vars, Tol = 1.0e-5, f(x₀) = 2.748885011116902e6 draw: 17 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:06
1: converged 2: converged 3: converged 4: converged 5: converged 

CRAGGLVY, 5000 vars, Tol = 1.0e-5, f(x₀) = 2.748885011116902e6
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           218.0       11.0 0.2019   true        1688.2153097145404 
ACX 3,2         177.0       11.0 0.1629   true        1688.2153097144371 
ACX 3,3,2       156.0       11.0 0.1431   true        1688.2153097146613 
L-BFGS          219.0      219.0 0.2869   true         1688.215309714383 
Conj Grad       128.0      221.0 0.2068   true         1688.215309714234 
Time left: 44 minutes, 9 seconds

CURLY10, 1000 vars, Tol = 1.0e-5, f(x₀) = -0.06301648215480213 draw: 18 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:53
1: converged 2: converged 3: converged 4: converged 5: converged 
Discrepancy: 198.5910216635093 Not accepted.

CURLY10, 1000 vars, Tol = 1.0e-5, f(x₀) = -0.06301648215480213
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2         32239.0        8.0 2.3961   true       -100316.29024001927 
ACX 3,2       26622.0        8.0 1.9781   true       -100117.69921966504 
ACX 3,3,2     19095.0        8.0 1.4181   true       -100316.29024019689 
L-BFGS        14723.0    14723.0 1.5460   true       -100316.29024132855 
Conj Grad     12066.0    19698.0 1.4927   true       -100316.29023994876 
Time left: 45 minutes, 15 seconds

CURLY20, 100 vars, Tol = 1.0e-8, f(x₀) = -0.012965350453989352 draw: 19 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:15
1: converged 2: converged 3: converged 4: converged 5: converged 

CURLY20, 100 vars, Tol = 1.0e-8, f(x₀) = -0.012965350453989352
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2          2557.0       10.0 0.0270   true       -10031.629024133126 
ACX 3,2        2574.0       10.0 0.0271   true       -10031.629024133126 
ACX 3,3,2      2258.0       10.0 0.0237   true       -10031.629024133126 
L-BFGS         2614.0     2614.0 0.0430   true       -10031.629024133033 
Conj Grad      1415.0     2471.0 0.0297   true       -10031.629024131907 
Time left: 43 minutes, 28 seconds

CURLY30, 100 vars, Tol = 1.0e-8, f(x₀) = -0.020382972047095268 draw: 20 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:19
1: converged 2: converged 3: converged 4: converged 5: converged 
Discrepancy: 27.195585752795523 Not accepted.

CURLY30, 100 vars, Tol = 1.0e-8, f(x₀) = -0.020382972047095268
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2          3508.0       12.0 0.0466   true       -10031.629024133126 
ACX 3,2        2973.0       12.0 0.0397   true        -10004.43343838033 
ACX 3,3,2      2591.0       12.0 0.0345   true       -10031.629024133126 
L-BFGS         1905.0     1905.0 0.0381   true       -10031.629024133055 
Conj Grad      1358.0     2444.0 0.0346   true       -10031.629024132544 
Time left: 42 minutes, 7 seconds

DECONVU, 63 vars, Tol = 1.0e-5, f(x₀) = 110.354018598764 draw: 21 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:04
1: converged 2: converged 3: converged 4: converged 5: converged 

DECONVU, 63 vars, Tol = 1.0e-5, f(x₀) = 110.354018598764
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           749.0       12.0 0.0152   true     2.8663951777891225e-7 
ACX 3,2         348.0       12.0 0.0071   true     3.4337766854436145e-7 
ACX 3,3,2       338.0       12.0 0.0069   true     2.9696372416434116e-7 
L-BFGS          196.0      196.0 0.0058   true     2.0319610705209036e-7 
Conj Grad       164.0      325.0 0.0063   true      3.233784038614493e-7 
Time left: 39 minutes, 53 seconds

DIXMAANA, 3000 vars, Tol = 1.0e-5, f(x₀) = 28501.0 draw: 22 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:02
1: converged 2: converged 3: converged 4: converged 5: converged 

DIXMAANA, 3000 vars, Tol = 1.0e-5, f(x₀) = 28501.0
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2             9.0       10.0 0.0043   true         1.000000000000407 
ACX 3,2           9.0       10.0 0.0044   true         1.000000000467905 
ACX 3,3,2        12.0       10.0 0.0054   true        1.0000000000002116 
L-BFGS           17.0       17.0 0.0081   true        1.0000000076407576 
Conj Grad         7.0       11.0 0.0039   true        1.0000000017709565 
Time left: 37 minutes, 47 seconds

DIXMAANB, 3000 vars, Tol = 1.0e-5, f(x₀) = 47242.0 draw: 23 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:03
1: converged 2: converged 3: converged 4: converged 5: converged 

DIXMAANB, 3000 vars, Tol = 1.0e-5, f(x₀) = 47242.0
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            11.0       11.0 0.0052   true        1.0000000000004634 
ACX 3,2          14.0       11.0 0.0062   true                       1.0 
ACX 3,3,2        12.0       11.0 0.0055   true         1.000000000034964 
L-BFGS           19.0       19.0 0.0091   true        1.0000000000196863 
Conj Grad        11.0       19.0 0.0064   true        1.0000000000000229 
Time left: 35 minutes, 53 seconds

DIXMAANC, 3000 vars, Tol = 1.0e-5, f(x₀) = 82483.0 draw: 24 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:03
1: converged 2: converged 3: converged 4: converged 5: converged 

DIXMAANC, 3000 vars, Tol = 1.0e-5, f(x₀) = 82483.0
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            13.0       12.0 0.0060   true        1.0000000000042724 
ACX 3,2          14.0       12.0 0.0064   true        1.0000000000039417 
ACX 3,3,2        15.0       12.0 0.0067   true        1.0000000001791332 
L-BFGS           21.0       21.0 0.0101   true         1.000000000002795 
Conj Grad        12.0       20.0 0.0069   true        1.0000000000011395 
Time left: 34 minutes, 9 seconds

DIXMAAND, 3000 vars, Tol = 1.0e-5, f(x₀) = 158603.56000000364 draw: 25 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:03
1: converged 2: converged 3: converged 4: converged 5: converged 

DIXMAAND, 3000 vars, Tol = 1.0e-5, f(x₀) = 158603.56000000364
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            15.0        5.0 0.0058   true        1.0000000000067464 
ACX 3,2          16.0        5.0 0.0062   true        1.0000000012272796 
ACX 3,3,2        17.0        5.0 0.0065   true         1.000000000012209 
L-BFGS           24.0       24.0 0.0115   true        1.0000000000004534 
Conj Grad        13.0       22.0 0.0075   true         1.000000000004967 
Time left: 32 minutes, 34 seconds

DIXMAANE, 3000 vars, Tol = 1.0e-5, f(x₀) = 22086.4166666668 draw: 26 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:04
1: converged 2: converged 3: converged 4: converged 5: converged 

DIXMAANE, 3000 vars, Tol = 1.0e-5, f(x₀) = 22086.4166666668
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           370.0       10.0 0.1302   true          1.00000007505598 
ACX 3,2         316.0       10.0 0.1120   true        1.0000000354474137 
ACX 3,3,2       289.0       10.0 0.1028   true        1.0000000594916478 
L-BFGS          555.0      555.0 0.2692   true        1.0000000830525635 
Conj Grad       181.0      359.0 0.1127   true        1.0000000824975304 
Time left: 31 minutes, 7 seconds

DIXMAANF, 3000 vars, Tol = 1.0e-5, f(x₀) = 41035.708333333205 draw: 27 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:20
1: converged 2: converged 3: converged 4: converged 5: converged 

DIXMAANF, 3000 vars, Tol = 1.0e-5, f(x₀) = 41035.708333333205
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           261.0       11.0 0.0920   true        1.0000000804299678 
ACX 3,2         353.0       11.0 0.1247   true         1.000000028420865 
ACX 3,3,2       321.0       11.0 0.1137   true        1.0000000698411076 
L-BFGS          408.0      408.0 0.1976   true        1.0000000540835656 
Conj Grad       141.0      279.0 0.0876   true        1.0000000401187785 
Time left: 30 minutes, 31 seconds

DIXMAANG, 3000 vars, Tol = 1.0e-5, f(x₀) = 76068.4166666668 draw: 28 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:11
1: converged 2: converged 3: converged 4: converged 5: converged 

DIXMAANG, 3000 vars, Tol = 1.0e-5, f(x₀) = 76068.4166666668
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           314.0       12.0 0.1105   true        1.0000000047950668 
ACX 3,2         291.0       12.0 0.1030   true        1.0000000637970405 
ACX 3,3,2       305.0       12.0 0.1080   true         1.000000028985048 
L-BFGS          400.0      400.0 0.1935   true        1.0000000599027212 
Conj Grad       139.0      274.0 0.0861   true        1.0000000429444007 
Time left: 29 minutes, 33 seconds

DIXMAANH, 3000 vars, Tol = 1.0e-5, f(x₀) = 151739.06666667032 draw: 29 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:19
1: converged 2: converged 3: converged 4: converged 5: converged 

DIXMAANH, 3000 vars, Tol = 1.0e-5, f(x₀) = 151739.06666667032
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           461.0        5.0 0.1607   true        1.0000000689164672 
ACX 3,2         299.0        5.0 0.1049   true         1.000000049963479 
ACX 3,3,2       236.0        5.0 0.0831   true        1.0000000198562093 
L-BFGS          388.0      388.0 0.1879   true        1.0000000846596175 
Conj Grad       137.0      270.0 0.0849   true        1.0000000466884278 
Time left: 28 minutes, 57 seconds

DIXMAANI, 3000 vars, Tol = 1.0e-6, f(x₀) = 20021.546527156082 draw: 30 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:54
1: converged 2: converged 3: converged 4: converged 5: converged 

DIXMAANI, 3000 vars, Tol = 1.0e-6, f(x₀) = 20021.546527156082
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2          3311.0       10.0 1.1510   true        1.0000006705362328 
ACX 3,2        4970.0       10.0 1.7357   true         1.000000822479231 
ACX 3,3,2      3996.0       10.0 1.3986   true         1.000000732521712 
L-BFGS         6038.0     6038.0 2.9344   true        1.0000005532573633 
Conj Grad      2854.0     5707.0 1.7897   true        1.0000001020808833 
Time left: 29 minutes, 43 seconds

DIXMAANJ, 3000 vars, Tol = 1.0e-5, f(x₀) = 39003.27337437024 draw: 31 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:30
1: converged 2: converged 3: converged 4: converged 5: converged 

DIXMAANJ, 3000 vars, Tol = 1.0e-5, f(x₀) = 39003.27337437024
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           233.0       11.0 0.0821   true        1.0000020840575792 
ACX 3,2         172.0       11.0 0.0613   true         1.000004922425973 
ACX 3,3,2       172.0       11.0 0.0614   true        1.0000046312004478 
L-BFGS          295.0      295.0 0.1428   true        1.0000033040616514 
Conj Grad       142.0      281.0 0.0882   true        1.0000010841003772 
Time left: 29 minutes, 29 seconds

DIXMAANK, 3000 vars, Tol = 1.0e-5, f(x₀) = 74003.54652715608 draw: 32 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:28
1: converged 2: converged 3: converged 4: converged 5: converged 

DIXMAANK, 3000 vars, Tol = 1.0e-5, f(x₀) = 74003.54652715608
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           167.0       12.0 0.0594   true        1.0000038982518553 
ACX 3,2         172.0       12.0 0.0615   true        1.0000032495659186 
ACX 3,3,2       185.0       12.0 0.0661   true        1.0000012277425459 
L-BFGS          262.0      262.0 0.1268   true        1.0000030744581587 
Conj Grad       133.0      262.0 0.0824   true         1.000000929185946 
Time left: 29 minutes, 10 seconds

DIXMAANL, 3000 vars, Tol = 1.0e-5, f(x₀) = 149604.13653716692 draw: 33 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:24
1: converged 2: converged 3: converged 4: converged 5: converged 

DIXMAANL, 3000 vars, Tol = 1.0e-5, f(x₀) = 149604.13653716692
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           178.0        5.0 0.0624   true        1.0000013285245892 
ACX 3,2         139.0        5.0 0.0492   true        1.0000038551995913 
ACX 3,3,2       135.0        5.0 0.0478   true        1.0000027999847763 
L-BFGS          234.0      234.0 0.1133   true        1.0000025905110486 
Conj Grad       117.0      230.0 0.0725   true        1.0000009461577155 
Time left: 28 minutes, 41 seconds

DIXMAANM, 3000 vars, Tol = 1.0e-6, f(x₀) = 9357.546527156082 draw: 34 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:01:01
1: converged 2: converged 3: converged 4: converged 5: converged 

DIXMAANM, 3000 vars, Tol = 1.0e-6, f(x₀) = 9357.546527156082
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2          4667.0        9.0 1.6236   true        1.0000011517712823 
ACX 3,2        6587.0        9.0 2.3047   true        1.0000011481213997 
ACX 3,3,2      3081.0        9.0 1.0800   true        1.0000008998171441 
L-BFGS         5801.0     5801.0 2.8209   true        1.0000009743940543 
Conj Grad      3770.0     7539.0 2.3644   true         1.000000130771953 
Time left: 29 minutes, 25 seconds

DIXMAANN, 3000 vars, Tol = 1.0e-5, f(x₀) = 20175.77337437028 draw: 35 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:05
1: converged 2: converged 3: converged 4: converged 5: converged 

DIXMAANN, 3000 vars, Tol = 1.0e-5, f(x₀) = 20175.77337437028
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           525.0       10.0 0.1839   true        1.0000033899355607 
ACX 3,2         499.0       10.0 0.1758   true        1.0000043730340975 
ACX 3,3,2       423.0       10.0 0.1494   true        1.0000039053156244 
L-BFGS          606.0      606.0 0.2938   true        1.0000074801271948 
Conj Grad       302.0      601.0 0.1886   true         1.000002270635091 
Time left: 28 minutes, 20 seconds

DIXMAANO, 3000 vars, Tol = 1.0e-5, f(x₀) = 36348.546527156104 draw: 36 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:05
1: converged 2: converged 3: converged 4: converged 5: converged 

DIXMAANO, 3000 vars, Tol = 1.0e-5, f(x₀) = 36348.546527156104
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           503.0       11.0 0.1759   true        1.0000046125430162 
ACX 3,2         506.0       11.0 0.1779   true        1.0000052535920596 
ACX 3,3,2       431.0       11.0 0.1521   true        1.0000035918874957 
L-BFGS          532.0      532.0 0.2575   true         1.000006837814114 
Conj Grad       273.0      542.0 0.1698   true         1.000002055843343 
Time left: 27 minutes, 18 seconds

DIXMAANP, 3000 vars, Tol = 1.0e-5, f(x₀) = 71281.7365370946 draw: 37 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:05
1: converged 2: converged 3: converged 4: converged 5: converged 

DIXMAANP, 3000 vars, Tol = 1.0e-5, f(x₀) = 71281.7365370946
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           497.0       12.0 0.1741   true        1.0000036849305467 
ACX 3,2         514.0       12.0 0.1811   true        1.0000014757091849 
ACX 3,3,2       353.0       12.0 0.1251   true        1.0000028133726109 
L-BFGS          556.0      556.0 0.2692   true        1.0000039361245505 
Conj Grad       245.0      486.0 0.1524   true         1.000001802351009 
Time left: 26 minutes, 19 seconds

DIXON3DQ, 1000 vars, Tol = 1.0e-8, f(x₀) = 8.0 draw: 38 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:21
1: converged 2: converged 3: converged 4: converged 5: converged 

DIXON3DQ, 1000 vars, Tol = 1.0e-8, f(x₀) = 8.0
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2         20933.0        7.0 0.8590   true      3.083904556957063e-8 
ACX 3,2       21836.0        7.0 0.8947   true      4.860071266755484e-7 
ACX 3,3,2      5830.0        7.0 0.2392   true     1.0513014087578073e-9 
L-BFGS         3002.0     3002.0 0.1847   true     4.524209968848404e-18 
Conj Grad      1002.0     2001.0 0.0838   true    3.8980869304384165e-17 
Time left: 25 minutes, 49 seconds

DQDRTIC, 5000 vars, Tol = 1.0e-5, f(x₀) = 9.041382e6 draw: 39 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:05
1: converged 2: converged 3: converged 4: converged 5: converged 

DQDRTIC, 5000 vars, Tol = 1.0e-5, f(x₀) = 9.041382e6
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            19.0        7.0 0.0104   true     4.569842926455945e-15 
ACX 3,2          26.0        7.0 0.0137   true    1.8662453430467045e-13 
ACX 3,3,2        15.0        7.0 0.0084   true     2.816242250292307e-18 
L-BFGS           16.0       16.0 0.0110   true     8.306369625405915e-25 
Conj Grad         7.0       11.0 0.0058   true    1.3668437997006108e-15 
Time left: 24 minutes, 53 seconds

DQRTIC, 5000 vars, Tol = 1.0e-6, f(x₀) = 6.240630415166874e17 draw: 40 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:13
1: converged 2: converged 3: converged 4: converged 5: converged 

DQRTIC, 5000 vars, Tol = 1.0e-6, f(x₀) = 6.240630415166874e17
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           135.0        9.0 0.0283   true       9.68737919902471e-8 
ACX 3,2          84.0        9.0 0.0179   true      6.454965116403506e-6 
ACX 3,3,2        97.0        9.0 0.0206   true     1.4472299910205257e-6 
L-BFGS          163.0      163.0 0.0505   true     2.2420711918208097e-8 
Conj Grad        36.0       68.0 0.0146   true     1.8396393218044136e-6 
Time left: 24 minutes, 13 seconds

EDENSCH, 2000 vars, Tol = 1.0e-5, f(x₀) = 7.358335e6 draw: 41 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:08
1: converged 2: converged 3: converged 4: converged 5: converged 

EDENSCH, 2000 vars, Tol = 1.0e-5, f(x₀) = 7.358335e6
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            44.0        7.0 0.0130   true        12003.284592020791 
ACX 3,2          49.0        7.0 0.0144   true        12003.284592020767 
ACX 3,3,2        41.0        7.0 0.0121   true         12003.28459202078 
L-BFGS           62.0       62.0 0.0245   true        12003.284592020756 
Conj Grad        38.0       65.0 0.0180   true        12003.284592020796 
Time left: 23 minutes, 26 seconds

EG2, 1000 vars, Tol = 1.0e-5, f(x₀) = -840.6295138230707 draw: 42 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:00
1: converged 2: converged 3: converged 4: converged 5: converged 

EG2, 1000 vars, Tol = 1.0e-5, f(x₀) = -840.6295138230707
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2             5.0        8.0 0.0008   true        -998.9473933009452 
ACX 3,2           6.0        8.0 0.0009   true         -998.947393300945 
ACX 3,3,2         7.0        8.0 0.0010   true        -998.9473933009451 
L-BFGS           15.0       15.0 0.0023   true        -998.9473933009451 
Conj Grad        10.0       12.0 0.0016   true        -998.9473933009893 
Time left: 22 minutes, 31 seconds

ENGVAL1, 5000 vars, Tol = 1.0e-5, f(x₀) = 294941.0 draw: 43 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:11
1: converged 2: converged 3: converged 4: converged 5: converged 

ENGVAL1, 5000 vars, Tol = 1.0e-5, f(x₀) = 294941.0
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            29.0        5.0 0.0163   true        5548.6684194150175 
ACX 3,2          34.0        5.0 0.0186   true         5548.668419415872 
ACX 3,3,2        31.0        5.0 0.0170   true         5548.668419415033 
L-BFGS           44.0       44.0 0.0327   true         5548.668419415847 
Conj Grad        31.0       51.0 0.0272   true         5548.668419415857 
Time left: 21 minutes, 53 seconds

ERRINRSM, 50 vars, Tol = 1.0e-8, f(x₀) = 152873.0724054592 draw: 44 
┌ Warning: Exceeded time limit of 100 seconds.
└ @ Main ~/Dropbox/Principal/Projets/Fixed-point/Julia_FixedPoint/main.jl:448
┌ Warning: Exceeded time limit of 100 seconds.
└ @ Main ~/Dropbox/Principal/Projets/Fixed-point/Julia_FixedPoint/main.jl:448
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:05:35
1: NOT converged 2: NOT converged 3: converged 4: converged 5: converged 
Discrepancy: 0.7895424003689584 Not accepted.

ERRINRSM, 50 vars, Tol = 1.0e-8, f(x₀) = 152873.0724054592
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2             Inf        Inf    Inf  false         37.72990289787323 
ACX 3,2           Inf        Inf    Inf  false         37.72990289886207 
ACX 3,3,2  1.1811801e        9.0 63.369   true         38.51944529810121 
L-BFGS          623.0      623.0 0.0060   true         37.72990289773225 
Conj Grad      6779.0     9659.0 0.0747   true         37.72990290041955 
Time left: 28 minutes, 7 seconds

EXTROSNB, 1000 vars, Tol = 1.0e-5, f(x₀) = 399604.0 draw: 45 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:49
1: converged 2: converged 3: converged 4: converged 5: converged 

EXTROSNB, 1000 vars, Tol = 1.0e-5, f(x₀) = 399604.0
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2         22501.0        8.0 1.7102   true     3.4917274032036504e-6 
ACX 3,2        8649.0        8.0 0.6024   true     3.6817565418723413e-6 
ACX 3,3,2      1246.0        8.0 0.0870   true      3.488978252442408e-6 
L-BFGS        10227.0    10227.0 1.0272   true      5.138190664422171e-9 
Conj Grad     25761.0    51511.0 3.3969   true     2.8180449017438204e-7 
Time left: 28 minutes, 1 second

FLETCBV2, 100 vars, Tol = 1.0e-5, f(x₀) = -0.513108296444765 draw: 46 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:02
1: converged 2: converged 3: converged 4: converged 5: converged 

FLETCBV2, 100 vars, Tol = 1.0e-5, f(x₀) = -0.513108296444765
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           308.0        5.0 0.0043   true       -0.5140045011536243 
ACX 3,2         252.0        5.0 0.0035   true       -0.5140067198734023 
ACX 3,3,2       177.0        5.0 0.0025   true        -0.514006278844702 
L-BFGS          277.0      277.0 0.0062   true       -0.5140067861817482 
Conj Grad        97.0      191.0 0.0030   true       -0.5140067865463609 
Time left: 26 minutes, 57 seconds

FLETCHCR, 1000 vars, Tol = 1.0e-5, f(x₀) = 999.0 draw: 47 
┌ Warning: Exceeded time limit of 100 seconds.
└ @ Main ~/Dropbox/Principal/Projets/Fixed-point/Julia_FixedPoint/main.jl:448
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:02:43
1: NOT converged 2: converged 3: converged 4: converged 5: converged 

FLETCHCR, 1000 vars, Tol = 1.0e-5, f(x₀) = 999.0
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2             Inf        Inf    Inf  false         933.9613051514721 
ACX 3,2       37963.0        6.0 3.6872   true     9.742581890489628e-12 
ACX 3,3,2     45895.0        6.0 4.4585   true     1.328708036047683e-10 
L-BFGS        11271.0    11271.0 1.5863   true    1.7512512339010445e-12 
Conj Grad      4358.0     8683.0 0.7881   true     3.865052393376907e-11 
Time left: 28 minutes, 58 seconds

FMINSRF2, 5625 vars, Tol = 1.0e-6, f(x₀) = 28.45833079116775 draw: 48 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:19
1: converged 2: converged 3: converged 4: converged 5: converged 

FMINSRF2, 5625 vars, Tol = 1.0e-6, f(x₀) = 28.45833079116775
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           844.0        6.0 0.6640   true        1.0000240996633505 
ACX 3,2         844.0        6.0 0.6537   true         1.000024416228861 
ACX 3,3,2       787.0        6.0 0.6072   true        1.0000241023650676 
L-BFGS          862.0      862.0 0.8848   true         1.000024084030896 
Conj Grad       355.0      707.0 0.4435   true        1.0000240799423004 
Time left: 28 minutes, 11 seconds

FMINSURF, 5625 vars, Tol = 1.0e-6, f(x₀) = 28.594016606596988 draw: 49 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:30
1: converged 2: converged 3: converged 4: converged 5: converged 

FMINSURF, 5625 vars, Tol = 1.0e-6, f(x₀) = 28.594016606596988
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2          1427.0        6.0 1.1602   true        1.0000065236848716 
ACX 3,2        1306.0        6.0 1.0456   true        1.0000037518321188 
ACX 3,3,2      1153.0        6.0 0.9200   true        0.9999999976832769 
L-BFGS         1242.0     1242.0 1.3237   true        1.0000000031173752 
Conj Grad       474.0      945.0 0.6126   true        0.9999999999294018 
Time left: 27 minutes, 37 seconds

FREUROTH, 5000 vars, Tol = 1.0e-5, f(x₀) = 5.0485565e6 draw: 50 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:22
1: converged 2: converged 3: converged 4: converged 5: converged 

FREUROTH, 5000 vars, Tol = 1.0e-5, f(x₀) = 5.0485565e6
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           261.0        7.0 0.1890   true         608159.1890462856 
ACX 3,2          81.0        7.0 0.0590   true         608159.1890463724 
ACX 3,3,2       100.0        7.0 0.0721   true         608159.1890462575 
L-BFGS           59.0       59.0 0.0595   true         608159.1890462552 
Conj Grad       231.0      343.0 0.2654   true         608159.1890464564 
Time left: 26 minutes, 55 seconds

GENHUMPS, 500 vars, Tol = 1.0e-5, f(x₀) = 1.2786741278198125e7 draw: 51 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:01:15
1: converged 2: converged 3: converged 4: converged 5: converged 

GENHUMPS, 500 vars, Tol = 1.0e-5, f(x₀) = 1.2786741278198125e7
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2         16381.0       10.0 1.7420   true    2.6540574332713912e-11 
ACX 3,2       50584.0       10.0 5.6550   true     3.087525220852477e-11 
ACX 3,3,2     36431.0       10.0 4.0897   true      2.38761137481953e-10 
L-BFGS         4260.0     4260.0 0.6168   true     3.244490895744304e-10 
Conj Grad      2130.0     4104.0 0.4181   true    2.2388023275923606e-10 
Time left: 27 minutes, 4 seconds

GENROSE, 500 vars, Tol = 1.0e-5, f(x₀) = 1870.0351331704708 draw: 52 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:05
1: converged 2: converged 3: converged 4: converged 5: converged 

GENROSE, 500 vars, Tol = 1.0e-5, f(x₀) = 1870.0351331704708
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2          4569.0       12.0 0.2237   true        1.0000000000000004 
ACX 3,2        3782.0       12.0 0.1850   true        1.0000000000017972 
ACX 3,3,2      3408.0       12.0 0.1668   true         1.000000000000916 
L-BFGS         2649.0     2649.0 0.1913   true        1.0000000000010765 
Conj Grad      1114.0     2192.0 0.1049   true        1.0000000000002638 
Time left: 26 minutes, 5 seconds

HILBERTB, 50 vars, Tol = 1.0e-5, f(x₀) = 2559.677480886595 draw: 53 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:00
1: converged 2: converged 3: converged 4: converged 5: converged 

HILBERTB, 50 vars, Tol = 1.0e-5, f(x₀) = 2559.677480886595
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2             8.0        9.0 0.0006   true      1.61415340349121e-11 
ACX 3,2           7.0        9.0 0.0006   true    1.2113787611038245e-11 
ACX 3,3,2         8.0        9.0 0.0006   true    2.3465256752600225e-14 
L-BFGS           12.0       12.0 0.0010   true     7.196825600688543e-13 
Conj Grad         6.0        9.0 0.0005   true     7.196825600690062e-13 
Time left: 25 minutes, 4 seconds

INTEQNELS, 502 vars, Tol = 1.0e-5, f(x₀) = 2.842027451153951 draw: 54 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:13
1: converged 2: converged 3: converged 4: converged 5: converged 

INTEQNELS, 502 vars, Tol = 1.0e-5, f(x₀) = 2.842027451153951
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2             7.0        8.0 0.0256   true      5.58142524974276e-10 
ACX 3,2           8.0        8.0 0.0271   true    4.2684176727277846e-10 
ACX 3,3,2         8.0        8.0 0.0264   true     6.745242731511448e-10 
L-BFGS           11.0       11.0 0.0367   true     9.162906119812457e-10 
Conj Grad         5.0        9.0 0.0178   true     2.8327720354665927e-9 
Time left: 24 minutes, 18 seconds

KSSLS, 1000 vars, Tol = 1.0e-5, f(x₀) = 3.980028990001e15 draw: 55 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:05
1: converged 2: converged 3: converged 4: converged 5: converged 

KSSLS, 1000 vars, Tol = 1.0e-5, f(x₀) = 3.980028990001e15
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            13.0       10.0 0.1689   true     2.418924822740528e-17 
ACX 3,2          14.0       10.0 0.1809   true    1.2535060752377079e-18 
ACX 3,3,2        17.0       10.0 0.2172   true     3.303495650138962e-20 
L-BFGS           16.0       16.0 0.2118   true     6.407171979783069e-20 
Conj Grad        11.0       18.0 0.1536   true    1.1369244257547632e-16 
Time left: 23 minutes, 31 seconds

LIARWHD, 5000 vars, Tol = 1.0e-5, f(x₀) = 2.925e6 draw: 56 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:15
1: converged 2: converged 3: converged 4: converged 5: converged 

LIARWHD, 5000 vars, Tol = 1.0e-5, f(x₀) = 2.925e6
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            59.0        9.0 0.0300   true     5.475834689041782e-19 
ACX 3,2          64.0        9.0 0.0323   true     5.357428683619007e-11 
ACX 3,3,2        68.0        9.0 0.0341   true     6.192607604872618e-13 
L-BFGS           43.0       43.0 0.0291   true    1.4572200704763226e-16 
Conj Grad        32.0       47.0 0.0248   true    3.5645511594618883e-19 
Time left: 22 minutes, 47 seconds

LUKSAN11LS, 100 vars, Tol = 1.0e-5, f(x₀) = 626.0639857227842 draw: 57 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:30
1: converged 2: converged 3: converged 4: converged 5: converged 

LUKSAN11LS, 100 vars, Tol = 1.0e-5, f(x₀) = 626.0639857227842
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2         89183.0        5.0 0.9430   true    1.9349891194985014e-14 
ACX 3,2        8111.0        5.0 0.0856   true     9.466535844311767e-18 
ACX 3,3,2      8226.0        5.0 0.0873   true      4.47118171294696e-15 
L-BFGS         2490.0     2490.0 0.0440   true    3.1751341092740427e-13 
Conj Grad       971.0     1922.0 0.0235   true    1.2665079954130513e-11 
Time left: 22 minutes, 16 seconds

LUKSAN13LS, 98 vars, Tol = 1.0e-5, f(x₀) = 64352.0 draw: 58 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:01
1: converged 2: converged 3: converged 4: converged 5: converged 

LUKSAN13LS, 98 vars, Tol = 1.0e-5, f(x₀) = 64352.0
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           215.0        8.0 0.0035   true        25188.859589645155 
ACX 3,2         199.0        8.0 0.0032   true        25188.859589645162 
ACX 3,3,2       196.0        8.0 0.0032   true        25188.859589645166 
L-BFGS          150.0      150.0 0.0037   true        25188.859589645173 
Conj Grad       180.0      291.0 0.0053   true        25188.859589645173 
Time left: 21 minutes, 24 seconds

LUKSAN15LS, 100 vars, Tol = 1.0e-5, f(x₀) = 27015.846760787113 draw: 59 
┌ Warning: Exceeded time limit of 100 seconds.
└ @ Main ~/Dropbox/Principal/Projets/Fixed-point/Julia_FixedPoint/main.jl:448
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:01:46
1: NOT converged 2: converged 3: converged 4: converged 5: converged 

LUKSAN15LS, 100 vars, Tol = 1.0e-5, f(x₀) = 27015.846760787113
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2             Inf        Inf    Inf  false         4371.473933261569 
ACX 3,2          67.0       11.0 0.0132   true         3.569696877226745 
ACX 3,3,2        33.0       11.0 0.0070   true        3.5696968772267135 
L-BFGS           91.0       91.0 0.0249   true        3.5696968772267086 
Conj Grad        49.0       74.0 0.0155   true        3.5696968772267224 
Time left: 21 minutes, 46 seconds

LUKSAN16LS, 100 vars, Tol = 1.0e-5, f(x₀) = 13068.484181197407 draw: 60 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:01
1: converged 2: converged 3: converged 4: converged 5: converged 

LUKSAN16LS, 100 vars, Tol = 1.0e-5, f(x₀) = 13068.484181197407
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            32.0       10.0 0.0019   true          3.56969687722674 
ACX 3,2          39.0       10.0 0.0023   true         3.569696877226721 
ACX 3,3,2        44.0       10.0 0.0025   true         3.569696877226798 
L-BFGS           98.0       98.0 0.0073   true        3.5696968772267015 
Conj Grad        51.0       77.0 0.0043   true        3.5696968772267197 
Time left: 20 minutes, 54 seconds

LUKSAN17LS, 100 vars, Tol = 1.0e-5, f(x₀) = 1.687370148927746e6 draw: 61 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:29
1: converged 2: converged 3: converged 4: converged 5: converged 

LUKSAN17LS, 100 vars, Tol = 1.0e-5, f(x₀) = 1.687370148927746e6
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           852.0        9.0 0.0948   true        0.4931612905950548 
ACX 3,2         881.0        9.0 0.0983   true         0.493161290566663 
ACX 3,3,2       685.0        9.0 0.0764   true       0.49316129062085895 
L-BFGS         1105.0     1105.0 0.2079   true       0.49316129037071754 
Conj Grad       502.0      992.0 0.1205   true        0.4931612903388112 
Time left: 20 minutes, 22 seconds

LUKSAN21LS, 100 vars, Tol = 1.0e-5, f(x₀) = 99.98750720033209 draw: 62 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:10
1: converged 2: converged 3: converged 4: converged 5: converged 

LUKSAN21LS, 100 vars, Tol = 1.0e-5, f(x₀) = 99.98750720033209
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2          1928.0        9.0 0.0172   true       1.20757425847371e-7 
ACX 3,2        2223.0        9.0 0.0198   true      3.158755121535808e-8 
ACX 3,3,2      1613.0        9.0 0.0145   true      4.370606706863602e-8 
L-BFGS         1572.0     1572.0 0.0232   true     8.964686202530688e-10 
Conj Grad      1462.0     2923.0 0.0307   true      4.112646859547974e-9 
Time left: 19 minutes, 38 seconds

MANCINO, 100 vars, Tol = 1.0e-5, f(x₀) = 1.1032125694308875e12 draw: 63 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:22
1: converged 2: converged 3: converged 4: converged 5: converged 

MANCINO, 100 vars, Tol = 1.0e-5, f(x₀) = 1.1032125694308875e12
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            13.0        8.0 0.0367   true      9.21366535376323e-21 
ACX 3,2          14.0        8.0 0.0387   true     1.255468755899666e-18 
ACX 3,3,2        13.0        8.0 0.0365   true    1.7710836140946304e-16 
L-BFGS           19.0       19.0 0.0606   true     4.097187178187508e-17 
Conj Grad        11.0       19.0 0.0454   true     9.306044890470045e-17 
Time left: 19 minutes, 2 seconds

MOREBV, 5000 vars, Tol = 1.0e-5, f(x₀) = 1.5969074274173896e-7 draw: 64 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:11
1: converged 2: converged 3: converged 4: converged 5: converged 

MOREBV, 5000 vars, Tol = 1.0e-5, f(x₀) = 1.5969074274173896e-7
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            33.0        9.0 0.0151   true     1.6901705994986855e-9 
ACX 3,2          22.0        9.0 0.0104   true     2.2088275392831606e-9 
ACX 3,3,2        30.0        9.0 0.0138   true     2.3425210127545446e-9 
L-BFGS           70.0       70.0 0.0407   true     1.3844392152011206e-9 
Conj Grad        38.0       73.0 0.0281   true     8.180279622416429e-10 
Time left: 18 minutes, 21 seconds

MSQRTALS, 1024 vars, Tol = 1.0e-5, f(x₀) = 7938.212984679468 draw: 65 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:02:52
1: converged 2: converged 3: converged 4: converged 5: converged 

MSQRTALS, 1024 vars, Tol = 1.0e-5, f(x₀) = 7938.212984679468
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2          3487.0       11.0 4.2118   true      9.529431966247368e-6 
ACX 3,2        4556.0       11.0 5.4510   true      9.675820545659185e-6 
ACX 3,3,2      4172.0       11.0 4.9728   true      5.492236809761684e-6 
L-BFGS         6186.0     6186.0 9.7429   true     4.5224813104985664e-8 
Conj Grad      2227.0     4444.0 4.3397   true      3.364027794591741e-8 
Time left: 19 minutes, 7 seconds

MSQRTBLS, 1024 vars, Tol = 1.0e-5, f(x₀) = 7926.444202823307 draw: 66 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:02:40
1: converged 2: converged 3: converged 4: converged 5: converged 

MSQRTBLS, 1024 vars, Tol = 1.0e-5, f(x₀) = 7926.444202823307
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2          6782.0       11.0 8.0492   true      2.517302488331628e-6 
ACX 3,2        3919.0       11.0 4.6024   true     2.8838094373504388e-6 
ACX 3,3,2      2982.0       11.0 3.4940   true     2.7597834306208528e-6 
L-BFGS         4530.0     4530.0 7.0313   true       5.05998956209889e-8 
Conj Grad      1846.0     3682.0 3.5567   true      4.848252175435632e-9 
Time left: 19 minutes, 40 seconds

NCB20B, 5000 vars, Tol = 1.0e-5, f(x₀) = 10000.0 draw: 67 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:04:24
1: converged 2: converged 3: converged 4: converged 5: converged 

NCB20B, 5000 vars, Tol = 1.0e-5, f(x₀) = 10000.0
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2          5623.0       10.0 27.531   true         7351.300594038846 
ACX 3,2        6341.0       10.0 31.346   true          7351.30059295448 
ACX 3,3,2      5003.0       10.0 24.430   true         7351.300595203104 
L-BFGS         2576.0     2576.0 18.387   true         7351.300597855715 
Conj Grad      3480.0     5892.0 30.654   true         7351.300594565538 
Time left: 20 minutes, 59 seconds

NONDIA, 5000 vars, Tol = 1.0e-5, f(x₀) = 1.999604e6 draw: 68 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:04
1: converged 2: converged 3: converged 4: converged 5: converged 

NONDIA, 5000 vars, Tol = 1.0e-5, f(x₀) = 1.999604e6
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            15.0        6.0 0.0065   true       2.61431123740951e-8 
ACX 3,2          16.0        6.0 0.0069   true      8.510290620933213e-9 
ACX 3,3,2        14.0        6.0 0.0061   true      8.508024875700233e-9 
L-BFGS           27.0       27.0 0.0140   true    3.2962687891314015e-18 
Conj Grad        23.0       28.0 0.0128   true     7.406134141785562e-18 
Time left: 20 minutes, 6 seconds

NONDQUAR, 5000 vars, Tol = 1.0e-7, f(x₀) = 5006.0 draw: 69 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:01:51
1: converged 2: converged 3: converged 4: converged 5: converged 

NONDQUAR, 5000 vars, Tol = 1.0e-7, f(x₀) = 5006.0
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2          7975.0        9.0 1.8833   true      1.935676336309693e-6 
ACX 3,2        7271.0        9.0 1.7165   true       2.05622733889097e-6 
ACX 3,3,2      7308.0        9.0 1.7253   true     1.7807751458401765e-6 
L-BFGS        27082.0    27082.0 9.4313   true      5.660474601052734e-8 
Conj Grad      9154.0    14185.0 3.7332   true      2.663607365518636e-7 
Time left: 20 minutes, 1 second

OSCIGRAD, 100000 vars, Tol = 1.0e-5, f(x₀) = 6.1207200225e8 draw: 70 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:01:30
1: converged 2: converged 3: converged 4: converged 5: converged 

OSCIGRAD, 100000 vars, Tol = 1.0e-5, f(x₀) = 6.1207200225e8
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            78.0       13.0 0.9914   true    1.0981469781633315e-17 
ACX 3,2          85.0       13.0 1.0445   true     4.129033614276534e-18 
ACX 3,3,2       104.0       13.0 1.2601   true     3.672631579645672e-17 
L-BFGS          228.0      228.0 7.6121   true     8.054323548626511e-18 
Conj Grad       102.0      170.0 4.1476   true     2.558618366968223e-18 
Time left: 19 minutes, 46 seconds

OSCIPATH, 500 vars, Tol = 1.0e-5, f(x₀) = 1.0 draw: 71 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:00
1: converged 2: converged 3: converged 4: converged 5: converged 

OSCIPATH, 500 vars, Tol = 1.0e-5, f(x₀) = 1.0
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            13.0        8.0 0.0005   true        0.9999666655201753 
ACX 3,2          11.0        8.0 0.0005   true        0.9999666655201764 
ACX 3,3,2        11.0        8.0 0.0005   true        0.9999666655201676 
L-BFGS           27.0       27.0 0.0014   true        0.9999666655201668 
Conj Grad        11.0       19.0 0.0007   true        0.9999666655201669 
Time left: 18 minutes, 51 seconds

PENALTY1, 1000 vars, Tol = 1.0e-5, f(x₀) = 1.1144480555533658e17 draw: 72 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:03
1: converged 2: converged 3: converged 4: converged 5: converged 

PENALTY1, 1000 vars, Tol = 1.0e-5, f(x₀) = 1.1144480555533658e17
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            65.0       13.0 0.0044   true      0.009686426817741085 
ACX 3,2          89.0       13.0 0.0059   true       0.00968842678807526 
ACX 3,3,2        79.0       13.0 0.0052   true       0.00968625706113825 
L-BFGS          176.0      176.0 0.0158   true      0.009687200779696583 
Conj Grad        64.0      100.0 0.0067   true      0.009687658616453416 
Time left: 17 minutes, 58 seconds

PENALTY2, 200 vars, Tol = 1.0e-5, f(x₀) = 4.711630255255825e13 draw: 73 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:06
1: converged 2: converged 3: converged 4: converged 5: converged 

PENALTY2, 200 vars, Tol = 1.0e-5, f(x₀) = 4.711630255255825e13
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           343.0        8.0 0.0159   true      4.711627728753194e13 
ACX 3,2         341.0        8.0 0.0158   true      4.711627728753194e13 
ACX 3,3,2       242.0        8.0 0.0113   true      4.711627728753194e13 
L-BFGS          200.0      200.0 0.0136   true      4.711627728753194e13 
Conj Grad       139.0      220.0 0.0112   true      4.711627728753194e13 
Time left: 17 minutes, 8 seconds

PENALTY3, 200 vars, Tol = 1.0e-5, f(x₀) = 1.5840723586360886e9 draw: 74 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:01:35
1: converged 2: converged 3: converged 4: converged 5: converged 

PENALTY3, 200 vars, Tol = 1.0e-5, f(x₀) = 1.5840723586360886e9
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           171.0        8.0 0.6631   true     0.0009986728653384206 
ACX 3,2         128.0        8.0 0.4983   true     0.0010004768371720254 
ACX 3,3,2       131.0        8.0 0.5094   true     0.0009985694885344214 
L-BFGS         6702.0     6702.0 35.447   true     0.0009980928774645165 
Conj Grad       444.0      508.0 2.4320   true     0.0009991618474549852 
Time left: 16 minutes, 51 seconds

POWELLSG, 5000 vars, Tol = 1.0e-6, f(x₀) = 268750.0 draw: 75 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:22
1: converged 2: converged 3: converged 4: converged 5: converged 

POWELLSG, 5000 vars, Tol = 1.0e-6, f(x₀) = 268750.0
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           215.0        7.0 0.0479   true     1.7690159527534775e-6 
ACX 3,2         231.0        7.0 0.0514   true      1.733508387449069e-6 
ACX 3,3,2       244.0        7.0 0.0542   true     1.4361027279694825e-6 
L-BFGS           82.0       82.0 0.0263   true    2.7253494735998097e-10 
Conj Grad      1917.0     3038.0 0.7499   true     4.4973174378272034e-8 
Time left: 16 minutes, 7 seconds

POWER, 10000 vars, Tol = 1.0e-5, f(x₀) = 2.500500025e15 draw: 76 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:13
1: converged 2: converged 3: converged 4: converged 5: converged 

POWER, 10000 vars, Tol = 1.0e-5, f(x₀) = 2.500500025e15
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2          1373.0       11.0 0.4488   true      1.882966396495075e-8 
ACX 3,2        1444.0       11.0 0.4721   true      2.831180376310022e-8 
ACX 3,3,2      1304.0       11.0 0.4264   true     1.1421030036676472e-8 
L-BFGS         1150.0     1150.0 0.5842   true      4.175004902418381e-8 
Conj Grad       389.0      752.0 0.2365   true     3.8464230885119857e-8 
Time left: 15 minutes, 21 seconds

QING, 100 vars, Tol = 1.0e-5, f(x₀) = 328350.0 draw: 77 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:00
1: converged 2: converged 3: converged 4: converged 5: converged 

QING, 100 vars, Tol = 1.0e-5, f(x₀) = 328350.0
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            94.0       11.0 0.0006   true     2.421675965042237e-12 
ACX 3,2          93.0       11.0 0.0006   true     3.660758634259698e-12 
ACX 3,3,2        94.0       11.0 0.0006   true     2.689248558571491e-12 
L-BFGS          179.0      179.0 0.0020   true    1.9543747584798806e-12 
Conj Grad        69.0      129.0 0.0011   true     1.863034298242349e-12 
Time left: 14 minutes, 31 seconds

QUARTC, 5000 vars, Tol = 1.0e-6, f(x₀) = 6.240630415166874e17 draw: 78 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:13
1: converged 2: converged 3: converged 4: converged 5: converged 

QUARTC, 5000 vars, Tol = 1.0e-6, f(x₀) = 6.240630415166874e17
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           135.0        9.0 0.0285   true       9.68737919902471e-8 
ACX 3,2          84.0        9.0 0.0181   true      6.454965116403506e-6 
ACX 3,3,2        97.0        9.0 0.0208   true     1.4472299910205257e-6 
L-BFGS          163.0      163.0 0.0504   true     2.2420711918208097e-8 
Conj Grad        36.0       68.0 0.0145   true     1.8396393218044136e-6 
Time left: 13 minutes, 47 seconds

SCHMVETT, 5000 vars, Tol = 1.0e-5, f(x₀) = -14294.606058008523 draw: 79 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:25
1: converged 2: converged 3: converged 4: converged 5: converged 

SCHMVETT, 5000 vars, Tol = 1.0e-5, f(x₀) = -14294.606058008523
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            54.0        8.0 0.0681   true       -14993.999999999993 
ACX 3,2          62.0        8.0 0.0771   true       -14993.999999999955 
ACX 3,3,2        74.0        8.0 0.0911   true       -14993.999999999989 
L-BFGS          102.0      102.0 0.1691   true       -14993.999999999924 
Conj Grad        52.0       91.0 0.1046   true       -14993.999999999956 
Time left: 13 minutes, 6 seconds

SINQUAD, 5000 vars, Tol = 1.0e-5, f(x₀) = 0.6561000000000001 draw: 80 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:17
1: converged 2: converged 3: converged 4: converged 5: converged 
Discrepancy: 1.008367120333571e6 Not accepted.

SINQUAD, 5000 vars, Tol = 1.0e-5, f(x₀) = 0.6561000000000001
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           103.0        9.0 0.0816   true      -6.757013757335634e6 
ACX 3,2         211.0        9.0 0.1646   true      -5.748646637002688e6 
ACX 3,3,2       163.0        9.0 0.1267   true      -6.757013757335967e6 
L-BFGS           59.0       59.0 0.0623   true      -6.757013757336246e6 
Conj Grad       155.0      199.0 0.1782   true      -6.757013757336259e6 
Time left: 12 minutes, 24 seconds

SPARSINE, 5000 vars, Tol = 1.0e-5, f(x₀) = 5.172633378795225e7 draw: 81 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:05:09
1: converged 2: converged 3: converged 4: NOT converged 5: NOT converged 

SPARSINE, 5000 vars, Tol = 1.0e-5, f(x₀) = 5.172633378795225e7
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2          8444.0       10.0 6.8097   true     1.1103104424298334e-7 
ACX 3,2       15457.0       10.0 12.277   true      2.411913277660355e-7 
ACX 3,3,2      9202.0       10.0 7.2800   true      2.306386443598591e-7 
L-BFGS            Inf        Inf    Inf  false      0.004932613792886696 
Conj Grad         Inf        Inf    Inf  false      6.273201760329937e-5 
Time left: 12 minutes, 50 seconds

SPARSQUR, 10000 vars, Tol = 1.0e-5, f(x₀) = 1.406390625e7 draw: 82 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:21
1: converged 2: converged 3: converged 4: converged 5: converged 

SPARSQUR, 10000 vars, Tol = 1.0e-5, f(x₀) = 1.406390625e7
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            85.0        9.0 0.1309   true      2.533304831729571e-7 
ACX 3,2          43.0        9.0 0.0672   true      4.704386376663658e-7 
ACX 3,3,2        46.0        9.0 0.0725   true      2.839439150502653e-7 
L-BFGS           99.0       99.0 0.1893   true     1.8055243082809276e-8 
Conj Grad        23.0       42.0 0.0508   true     1.2476211958929114e-7 
Time left: 12 minutes, 6 seconds

SPIN2LS, 102 vars, Tol = 1.0e-5, f(x₀) = 32562.50000467878 draw: 83 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:06
1: converged 2: converged 3: converged 4: converged 5: converged 

SPIN2LS, 102 vars, Tol = 1.0e-5, f(x₀) = 32562.50000467878
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            39.0        8.0 0.0111   true      2.46286360678352e-12 
ACX 3,2          37.0        8.0 0.0106   true     6.321526332038909e-13 
ACX 3,3,2        52.0        8.0 0.0147   true      5.94804792720776e-11 
L-BFGS           52.0       52.0 0.0170   true     4.142039585324236e-13 
Conj Grad        33.0       62.0 0.0122   true     2.056686934010247e-12 
Time left: 11 minutes, 19 seconds

SPMSRTLS, 4999 vars, Tol = 1.0e-5, f(x₀) = 4141.244262299877 draw: 84 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:09
1: converged 2: converged 3: converged 4: converged 5: converged 

SPMSRTLS, 4999 vars, Tol = 1.0e-5, f(x₀) = 4141.244262299877
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           337.0        7.0 0.2621   true      2.264007317185582e-9 
ACX 3,2         299.0        7.0 0.2292   true      1.586511871894641e-9 
ACX 3,3,2       307.0        7.0 0.2342   true      1.395497990055798e-9 
L-BFGS          492.0      492.0 0.5366   true      8.396656225856227e-9 
Conj Grad       180.0      350.0 0.2435   true     3.2151534992044788e-9 
Time left: 10 minutes, 33 seconds

SROSENBR, 5000 vars, Tol = 1.0e-5, f(x₀) = 48500.00000000295 draw: 85 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:03
1: converged 2: converged 3: converged 4: converged 5: converged 

SROSENBR, 5000 vars, Tol = 1.0e-5, f(x₀) = 48500.00000000295
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            23.0        8.0 0.0068   true     1.934210756938266e-11 
ACX 3,2          19.0        8.0 0.0058   true     1.0039914255239317e-8 
ACX 3,3,2        36.0        8.0 0.0102   true     3.095864869518721e-11 
L-BFGS           24.0       24.0 0.0088   true       2.55517243039076e-8 
Conj Grad        15.0       21.0 0.0063   true    1.0127504060727507e-11 
Time left: 9 minutes, 47 seconds

SSBRYBND, 1000 vars, Tol = 1.0e-5, f(x₀) = 24903.99999872156 draw: 86 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:02:04
1: converged 2: converged 3: converged 4: converged 5: converged 

SSBRYBND, 1000 vars, Tol = 1.0e-5, f(x₀) = 24903.99999872156
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2         23160.0       11.0 3.9932   true    3.0657468058797485e-13 
ACX 3,2       18587.0       11.0 3.2052   true    2.6925687601329628e-11 
ACX 3,3,2     43306.0       11.0 7.4625   true    3.1679671926083456e-11 
L-BFGS        17307.0    17307.0 3.9648   true     8.326909577759335e-13 
Conj Grad      7361.0    14693.0 2.1129   true     1.393991897105633e-13 
Time left: 9 minutes, 22 seconds

STRTCHDV, 10 vars, Tol = 1.0e-5, f(x₀) = 7.186050012059551 draw: 87 
1: converged 2: converged 3: converged 4: converged 5: converged 

STRTCHDV, 10 vars, Tol = 1.0e-5, f(x₀) = 7.186050012059551
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            40.0        5.0 0.0001   true     1.0931701713597586e-7 
ACX 3,2          46.0        5.0 0.0002   true      5.351354079136263e-8 
ACX 3,3,2        41.0        5.0 0.0001   true      1.138292532231667e-7 
L-BFGS           51.0       51.0 0.0003   true      5.674322768607967e-9 
Conj Grad        35.0       63.0 0.0003   true     5.5765793447296396e-8 
Time left: 8 minutes, 36 seconds

TESTQUAD, 5000 vars, Tol = 1.0e-5, f(x₀) = 1.2500006249996102e9 draw: 88 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:53
1: converged 2: converged 3: converged 4: converged 5: converged 

TESTQUAD, 5000 vars, Tol = 1.0e-5, f(x₀) = 1.2500006249996102e9
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2         14169.0        6.0 2.4390   true     1.768794347138659e-13 
ACX 3,2       17414.0        6.0 2.9757   true     8.235924939360225e-12 
ACX 3,3,2     11613.0        6.0 1.9880   true     2.123975288502749e-11 
L-BFGS         3943.0     3943.0 0.9987   true     9.446547630803481e-11 
Conj Grad      1520.0     3037.0 0.5074   true    2.4743783670278367e-11 
Time left: 7 minutes, 58 seconds

TOINTGOR, 50 vars, Tol = 1.0e-5, f(x₀) = 5073.786371010433 draw: 89 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:00
1: converged 2: converged 3: converged 4: converged 5: converged 

TOINTGOR, 50 vars, Tol = 1.0e-5, f(x₀) = 5073.786371010433
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           218.0       12.0 0.0013   true         1373.905460663645 
ACX 3,2         190.0       12.0 0.0012   true         1373.905460663652 
ACX 3,3,2       161.0       12.0 0.0010   true        1373.9054606639834 
L-BFGS          276.0      276.0 0.0030   true        1373.9054606637014 
Conj Grad       113.0      223.0 0.0017   true        1373.9054606637221 
Time left: 7 minutes, 14 seconds

TOINTGSS, 5000 vars, Tol = 1.0e-5, f(x₀) = 44991.99999999686 draw: 90 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:02
1: converged 2: converged 3: converged 4: converged 5: converged 

TOINTGSS, 5000 vars, Tol = 1.0e-5, f(x₀) = 44991.99999999686
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2             2.0        7.0 0.0027   true        10.002000799679799 
ACX 3,2           2.0        7.0 0.0027   true        10.002000799679799 
ACX 3,3,2         2.0        7.0 0.0027   true        10.002000799679799 
L-BFGS            7.0        7.0 0.0060   true         10.00200079969567 
Conj Grad         4.0        7.0 0.0041   true        10.002000799724097 
Time left: 6 minutes, 30 seconds

TOINTPSP, 50 vars, Tol = 1.0e-5, f(x₀) = 1827.708571428571 draw: 91 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:01
1: converged 2: converged 3: converged 4: converged 5: converged 

TOINTPSP, 50 vars, Tol = 1.0e-5, f(x₀) = 1827.708571428571
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           696.0        9.0 0.0030   true         225.5604094219355 
ACX 3,2        2506.0        9.0 0.0107   true        225.56040942192215 
ACX 3,3,2       212.0        9.0 0.0009   true         225.5604094219003 
L-BFGS          202.0      202.0 0.0016   true        225.56040942191103 
Conj Grad       143.0      262.0 0.0016   true        225.56040942190404 
Time left: 5 minutes, 47 seconds

TOINTQOR, 50 vars, Tol = 1.0e-5, f(x₀) = 2335.2875000000004 draw: 92 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:00
1: converged 2: converged 3: converged 4: converged 5: converged 

TOINTQOR, 50 vars, Tol = 1.0e-5, f(x₀) = 2335.2875000000004
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            61.0       11.0 0.0002   true        1175.4722221462175 
ACX 3,2          51.0       11.0 0.0002   true         1175.472222146219 
ACX 3,3,2        57.0       11.0 0.0002   true        1175.4722221461698 
L-BFGS           72.0       72.0 0.0005   true        1175.4722221462073 
Conj Grad        29.0       55.0 0.0003   true        1175.4722221461955 
Time left: 5 minutes, 5 seconds

TQUARTIC, 5000 vars, Tol = 1.0e-6, f(x₀) = 0.81 draw: 93 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:10
1: converged 2: converged 3: converged 4: converged 5: converged 

TQUARTIC, 5000 vars, Tol = 1.0e-6, f(x₀) = 0.81
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           415.0        7.0 0.1430   true     3.6308498357090357e-6 
ACX 3,2        1439.0        7.0 0.4939   true      5.473625367851922e-6 
ACX 3,3,2        75.0        7.0 0.0265   true      3.687505424898142e-6 
L-BFGS           33.0       33.0 0.0155   true    1.6987382823682235e-18 
Conj Grad        53.0       63.0 0.0256   true    1.3649797929361754e-14 
Time left: 4 minutes, 25 seconds

TRIDIA, 5000 vars, Tol = 1.0e-5, f(x₀) = 1.2502499e7 draw: 94 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:18
1: converged 2: converged 3: converged 4: converged 5: converged 

TRIDIA, 5000 vars, Tol = 1.0e-5, f(x₀) = 1.2502499e7
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2          2891.0       11.0 0.5891   true    2.0148071881232023e-11 
ACX 3,2        3711.0       11.0 0.7555   true      5.23217721969153e-12 
ACX 3,3,2      3563.0       11.0 0.7250   true    5.1540104840785006e-11 
L-BFGS         2174.0     2174.0 0.6583   true    1.2947058197529893e-12 
Conj Grad       737.0     1471.0 0.2969   true     5.956648764059128e-13 
Time left: 3 minutes, 46 seconds

TRIGON1, 10 vars, Tol = 1.0e-5, f(x₀) = 2.966540465329251 draw: 95 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:00
1: converged 2: converged 3: converged 4: converged 5: converged 

TRIGON1, 10 vars, Tol = 1.0e-5, f(x₀) = 2.966540465329251
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           110.0        5.0 0.0003   true    1.2104831859925485e-12 
ACX 3,2          84.0        5.0 0.0002   true    2.0678435210531443e-12 
ACX 3,3,2       104.0        5.0 0.0002   true      6.94154512397659e-12 
L-BFGS           52.0       52.0 0.0002   true     9.965494947827872e-13 
Conj Grad        44.0       85.0 0.0003   true     1.395599251591289e-11 
Time left: 3 minutes, 6 seconds

VARDIM, 200 vars, Tol = 1.0e-5, f(x₀) = 3.2565422800090564e16 draw: 96 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:00
1: converged 2: converged 3: converged 4: converged 5: converged 

VARDIM, 200 vars, Tol = 1.0e-5, f(x₀) = 3.2565422800090564e16
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            53.0       13.0 0.0005   true     3.069911493325117e-16 
ACX 3,2          76.0       13.0 0.0007   true    2.3218082200781273e-20 
ACX 3,3,2        81.0       13.0 0.0008   true     2.547809347426546e-16 
L-BFGS          102.0      102.0 0.0015   true    1.2523621888244031e-17 
Conj Grad        72.0       94.0 0.0012   true     3.451895153439748e-20 
Time left: 2 minutes, 28 seconds

VAREIGVL, 5000 vars, Tol = 1.0e-5, f(x₀) = 251494.32120489716 draw: 97 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:10
1: converged 2: converged 3: converged 4: converged 5: converged 

VAREIGVL, 5000 vars, Tol = 1.0e-5, f(x₀) = 251494.32120489716
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           129.0        5.0 0.1187   true     1.5876990280897684e-7 
ACX 3,2         139.0        5.0 0.1262   true     1.6890170884207382e-7 
ACX 3,3,2       153.0        5.0 0.1384   true      8.851035460765848e-8 
L-BFGS           58.0       58.0 0.0715   true     8.875643767657028e-11 
Conj Grad       112.0      220.0 0.1681   true     1.1370394041309587e-8 
Time left: 1 minute, 50 seconds

WOODS, 4000 vars, Tol = 1.0e-5, f(x₀) = 1.9192e7 draw: 98 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:00:21
1: converged 2: converged 3: converged 4: converged 5: converged 

WOODS, 4000 vars, Tol = 1.0e-5, f(x₀) = 1.9192e7
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2           357.0       10.0 0.0994   true      4.214840009878382e-8 
ACX 3,2         371.0       10.0 0.1033   true     9.887568276986546e-10 
ACX 3,3,2       252.0       10.0 0.0705   true     1.4046407424501586e-7 
L-BFGS           58.0       58.0 0.0231   true    1.5656757408902484e-13 
Conj Grad       438.0      835.0 0.2219   true     3.4211702173296958e-9 
Time left: 1 minute, 13 seconds

YATP1CLS, 123200 vars, Tol = 1.0e-5, f(x₀) = 2.540369484530258e9 draw: 99 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:02:28
1: converged 2: converged 3: converged 4: converged 5: converged 

YATP1CLS, 123200 vars, Tol = 1.0e-5, f(x₀) = 2.540369484530258e9
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            31.0       10.0 3.0512   true    2.0664870245773227e-15 
ACX 3,2          34.0       10.0 3.3502   true     6.567382914858615e-10 
ACX 3,3,2        36.0       10.0 3.4685   true    1.0515190995057822e-10 
L-BFGS           44.0       44.0 6.7996   true     1.084134592483256e-13 
Conj Grad        47.0       66.0 7.8268   true     2.502280401722518e-14 

YATP2CLS, 123200 vars, Tol = 1.0e-5, f(x₀) = 7.672672046768764e9 draw: 100 
Progress: 100%|████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| Time: 0:01:22
1: converged 2: converged 3: converged 4: converged 5: converged 

YATP2CLS, 123200 vars, Tol = 1.0e-5, f(x₀) = 7.672672046768764e9
Algorithm   Grad eval   Obj eval    sec   Conv                   Minimum 
ACX 2            18.0        5.0 1.4666   true      7.28830857840465e-17 
ACX 3,2          33.0        5.0 2.2578   true     6.281320447751308e-13 
ACX 3,3,2        70.0        5.0 4.2564   true    3.4093547384488844e-13 
L-BFGS           29.0       29.0 3.3552   true     1.773662221717972e-16 
Conj Grad        20.0       24.0 2.3952   true      6.69496480095653e-17
=#



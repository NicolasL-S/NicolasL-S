"""
	no_accel applies a mapping until convergence (aka a Picard iterative process).
"""

mud(x, m) = mod.(x .- 1, m) .+ 1
function no_accel(x_in, map!; f = nothing, maps_limit = 1_000_000, tol = 1e-8, 
	verb = 0, Lp = 2, time_limit = 1000, interval_show_progress = Inf)

	start_time = time()
	xs = [x_in[:], similar(x_in[:])]
	n_maps = 0
	i_x = 1
	while n_maps <= maps_limit && time() - start_time < time_limit
		n_maps += 1
		map!(xs[mud(i_x + 1,2)], xs[i_x])
		i_x = mud(i_x + 1,2)
		normΔ = norm(xs[1] - xs[2], Lp)
		if mod(n_maps, interval_show_progress) == 0; 
			str = "n_maps: $n_maps, normΔ: $normΔ"
			if f !== nothing; str *= ", Objective: " * string(f(xs[mud(i_x - 1,2)])) end
			println(str)
		end
		if isnan(normΔ) || isinf(normΔ)
			if verb >= 1 print("Not converged, NaN values.") end
			return xs[i_x], n_maps, false 
		elseif normΔ < tol
			if verb >= 1; println("Converged. Number of mappings: ", n_maps, " ")  end
			return xs[i_x], n_maps, true
		end
	end
	if verb >= 1 && n_maps > maps_limit
		println("Maximum mappings of $maps_limit exceeded.") 
	else
		println("Time limit of $time_limit sec. exceeded.") 
	end
	return xs[i_x], n_maps, false
end
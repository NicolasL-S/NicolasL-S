"""
	Generates all figures and tables. 
	
	Notes:
	- The path_output below must be changed.
	- The codes were run on Julia 1.6.1
	- The plots for the paper were generated using pyplot (put it back by 
	  uncommenting the line in plot_draws). 
	- The CUTEst application requires CUTEst (only available on Linux and Mac)
	- The censPHEM application requires R with the package "daaremtest"
"""

# Change the output path
if Sys.iswindows()
    path_output = "C:\\Users\\Nicolas\\Dropbox\\Principal\\Projets\\Fixed-point\\Results\\"
else
    path_output = "/home/nicolas/Dropbox/Principal/Projets/Fixed-point/Results/"
end

using BenchmarkTools, LaTeXStrings, Distributions, Optim, Random, LineSearches,
    StatsFuns, JLD, DelimitedFiles, CSV, DataFrames, RCall, ProgressMeter, Dates

include("main.jl")
include("daarem_base_objfn.jl")
include("daarem_base_noobjfn.jl")
include("qnamm.jl")
include("no_accel.jl")
include("Constants.jl")
include("table_display.jl")
include("plot_draws.jl")

# Figure 1
include("Example_linear_model.jl")

# Figure 2
include("Example_Rosenbrock.jl")

# All applications
include("applications.jl")

#= Note: the versions of the packages used for the project were the following:

Status `~/.julia/environments/v1.6/Project.toml`
             [22286c92] AccurateArithmetic v0.3.7
             [7d9fca2a] Arpack v0.5.2
             [6e4b80f9] BenchmarkTools v1.0.0
             [ad839575] Blink v0.12.5
             [336ed68f] CSV v0.8.5
             [1b53aba6] CUTEst v0.11.1
             [159f3aea] Cairo v1.0.5
             [3da002f7] ColorTypes v0.11.0
             [a93c6f00] DataFrames v1.1.1
             [31c24e10] Distributions v0.25.2
             [9d5cd8c9] FixedEffectModels v1.6.1
             [f6369f11] ForwardDiff v0.10.18
             [28b8d3ca] GR v0.57.5
             [b6b21f68] Ipopt v0.6.5
             [4138dd39] JLD v0.12.3
             [ba0b0d4f] Krylov v0.7.3
             [0b1a1467] KrylovKit v0.5.3
             [b964fa9f] LaTeXStrings v1.2.1
             [d3d80556] LineSearches v7.1.1
             [46d2c3a1] MuladdMacro v0.2.2
             [a4795742] NLPModels v0.14.1
             [429524aa] Optim v1.3.0
             [cec144fc] OptimTestProblems v2.0.2
             [f0f68f2c] PlotlyJS v0.14.1
             [91a5bcdd] Plots v1.15.2
             [c46f51b8] ProfileView v0.6.10
             [92933f4c] ProgressMeter v1.7.1
             [438e738f] PyCall v1.92.3
             [d330b81b] PyPlot v2.9.0
             [be4d8f0f] Quadmath v0.5.5
             [6f49c342] RCall v0.13.11
             [c4c386cf] Rsvg v1.0.0
             [276daf66] SpecialFunctions v1.4.2
             [90137ffa] StaticArrays v1.2.2
             [4c63d2b9] StatsFuns v0.9.8
             [8ba89e20] Distributed
             [2f01184e] SparseArrays
             [8dfed614] Test
=#
using RCall, Statistics
RCall.@rlibrary(daaremtest)

function EMadmixture!(param_out, param_in, X, K)
    eps = 1e-6
    n, p = size(X)
    m = eps * ones(n, K)
    n0 = eps * ones(p, K)
    n1 = eps * ones(p, K)
    FF = logistic.(reshape(param_in[1:(p * K)], (p, K)))
    OneMinusFF = 1 .- FF
    Q = exp.(reshape(param_in[(p * K + 1):(p * K + n * K)], (n, K)))
    Q ./= sum(Q; dims = 2)
    r = Array{eltype(param_in)}(undef, p, 4, K, K)
    S1 = Array{eltype(param_in)}(undef, p, 4, 1, K)
    S2 = Array{eltype(param_in)}(undef, p, 4, K, 1)
    Xzeros, Xones, Xtwos = (similar(X[1,:]), similar(X[1,:]), similar(X[1,:]))
    for i ∈ 1:n
        Xzeros .= X[i,:] .== 0
        Xones  .= X[i,:] .== 1
        Xtwos  .= X[i,:] .== 2
        for j ∈ 1:K, k ∈ 1:K
            @. r[:, 1, j, k] = Xzeros * OneMinusFF[:,j] * OneMinusFF[:,k]
            @. r[:, 2, j, k] = Xones  * OneMinusFF[:,j] *         FF[:,k]
            @. r[:, 3, j, k] = Xones  *         FF[:,j] * OneMinusFF[:,k]
            @. r[:, 4, j, k] = Xtwos  *         FF[:,j] *         FF[:,k]
            @. r[:, :, j, k] *= Q[i, j] * Q[i, k]
        end
    
        r = reshape(r, (p, 4K^2))
        r = reshape(r ./= sum(r; dims = 2), (p, 4, K, K))
        m[i,:] .+= [sum(r[:, :, l, :]) for l ∈ 1:K] .+ [sum(r[:, :, :, l]) for l ∈ 1:K]
        S1 .= sum(r[:, :, :, :]; dims = 3)
        S2 .= sum(r[:, :, :, :]; dims = 4)
        n0 .+= S2[:, 1, :, 1] .+ S2[:, 2, :, 1] .+ S1[:, 1, 1, :] .+ S1[:, 3, 1, :]
        n1 .+= S2[:, 3, :, 1] .+ S2[:, 4, :, 1] .+ S1[:, 2, 1, :] .+ S1[:, 4, 1, :]
    end
    param_out .= log.([reshape(n1 ./ n0 ,(p * K, )); reshape(m, (n * K, ))])
    return param_out
end

function LogLikAdmixTrans(param, X, K)
  n, p = size(X)
  FF = logistic.(reshape(param[1:(p * K)], (p, K)))
  Q = exp.(reshape(param[(p * K + 1):(p * K + n * K)], (n, K)))
  Q ./= sum(Q; dims = 2)
  return sum(X .* log.(Q * FF')) + sum((2 .- X) .* log.(Q * (1 .- FF')))
end

function gen_problem_ancestry(par, spec, draw)
    K = 3
    p = 100
    n = 150

    Ftmp = rand(p * K)
    geno = rcopy(AdmixGenerate(p = p, K = 3, n = n, e = 0.01))

    return (
        f         = param -> -LogLikAdmixTrans(param, geno, K),
        m!        = (out, in) -> EMadmixture!(out, in, geno, K),
        x_in      = log.([Ftmp ./ (1 .- Ftmp); rand(n * K)]), 
        check_res = param -> -LogLikAdmixTrans(param, geno, K))
end

function modif_par_ancestry!(par)
    par.title = "Ancestry estimation problem"
    par.discrep_answers = ∞
    par.freq_display = 1
    par.tol = 1e-6
    par.algos = [1, 2, 3, 4, 21]
    return par
end

if @isdefined modif_param_dict
    modif_param_dict["ancestry"] = modif_par_ancestry!
    gen_problem_dict["ancestry"] = gen_problem_ancestry
end